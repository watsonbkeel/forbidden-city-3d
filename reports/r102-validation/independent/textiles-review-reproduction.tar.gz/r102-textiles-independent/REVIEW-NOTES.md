# R102 independent review — in progress

Read-only product review; evidence under this directory only.

## Source / scope
Personally viewed both original official reference images and checked full SHA256:
- jiaotai-interior-1.jpg: 409278e71e169b7534af75ea971cc68c89126897c3731b4723f8ee9151c27da8
- jiaotai-clock-context.jpg: 6e68bdf3832a63f6f9f0332a43517406105d62a6c97cccdc514ba01a504f1973
Yellow cloth with lighter dense pattern and rug border/blue field divisions are supported qualitatively. Motif identity, original dye colors, dimensions, actual count and photography date are not established. No original reference images copied here or into release.

Baseline actual R101 Jiaotai fragment: 221 meshes; 27 allowed material/UV targets and 194 other meshes. `snapshot.mjs` hashes all attributes, indices and world matrices, snapshots actual colliders/walkables before dispose. `compare.mjs` enforces exact non-UV geometry/physics and non-target material retention. No new path matrix needed if physical inputs remain exact.

## Environment correction
@napi-rs/canvas was declared but absent from node_modules/cache. No successful Canvas execution is claimed. Writer/root switched to one production pure RGBA array generator and THREE.DataTexture. Review will check real image.data and lossless PNG encoding, not mock canvas. DataTexture flipY/filter/mipmap/colorSpace semantics must match CPU sampler; CPU imagery is not GPU validation.

## Scope of fixture
The generic R54 hallFragment cannot construct current Qianqing with its obsolete shared height (throws Unregistered Qianqing passage envelope). Independent local snapshot therefore intentionally targets Jiaotai only, not a claimed three-hall runtime snapshot. Cross-hall preservation needs source isolation/full appropriate builder proof separately.

Pending: stable implementation/hash, actual texture pixels/UV, lifecycle counts and paired views.
