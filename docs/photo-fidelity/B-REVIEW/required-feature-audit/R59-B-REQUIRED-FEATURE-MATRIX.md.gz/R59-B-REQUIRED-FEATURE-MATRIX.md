# R59-B 全量必需特征差异/审查矩阵

基线 `799390a`。41 个原 FC 的 577 条 canonical 特征全部保留，另审 6 个 AUX 声明。不是 47 栋实体。所有状态保留，不新增 ACCEPTED。

本报告没有几何修改、浏览器验收或全世界构造。已读取并保留 reports/r59-b-batch1/SUMMARY.json 的累计功能检查通过史，未自行重跑；源码/CPU结果不替代浏览器照片对照。最后元数据快照详见 JSON，生产代码仍为799390a范围。来源是否本次实际看像素见同名 JSON 的 sourceCatalog。

## 分类

- EXISTING_REQUIRES_BROWSER: 已有实现，需实机匹配对照；不是通过，也不是重建许可（原特征 103 条）
- SOURCE_PRESENT_IMPLEMENTATION: 证据支持有限内容，尚需实现/局部修正（原特征 7 条）
- SOURCE_PRESENT_REGISTRATION: 来源已在，实体映射/版本/子项登记尚待处理（原特征 158 条）
- FEATURE_SOURCE_GAP: 只有本特征或本视角缺证，不等于整个对象无来源（原特征 268 条）
- HISTORICAL_NOT_CURRENT: 已证历史不存；保留任务及沿革，不建当代壳（原特征 14 条）
- AGGREGATE_OR_NOT_APPLICABLE: 父级汇总或本角色不适用；不删除原任务（原特征 18 条）
- IMPLEMENTED_VERIFY_PENDING: 本轮已做有限改动，实际浏览器证据仍待补（原特征 9 条）

## FC-CD0B5AC9DE · 文华殿

已有专用工字殿/展陈，接续 R39/R48；不重建、不回退为无图空壳。
原要求：工字形主殿前殿，五间三进深、黄瓦歇山、三交六椀槅扇；与后殿主敬殿以穿廊连接。；本页混有文华门、文渊阁及院落后侧照片；本殿室内未由本页核到。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:383`。绑定：data/zones/outer-east.json#/items/2

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：官网工字形前殿/穿廊/后殿关系；地图不是米制定位。
  - 实现：文华殿已有 front 专用声明与 exact-profile，非缺壳。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：前殿五间三进深黄瓦歇山；后殿稍浅；穿廊独立低屋顶，不能混为同一殿屋面。
  - 实现：SouthCourtHalls 使用保留歇山 hall 或旋转 gable 穿廊屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：官网开间与既有独立柱列，三交六椀是前殿要求，不自动复制到穿廊。
  - 实现：沿用五开间 hall 与单跨穿廊拟合；非实测彩画/斗栱。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：本对象的前后开口及穿廊连接；其余立面仍须分方向观察。
  - 实现：正殿/后殿前后 portal 已有；穿廊两端开通、侧墙连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：月台甬路和共有地坪关系，尺寸不是测绘。
  - 实现：三个对象楼面均 1.2；相接内阶藏于连接台基下，安全连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：前后殿通过穿廊连续连接；其端部不是横墙或独立台阶。
  - 实现：文华前殿后缘 -190.5 与穿廊南端、后殿前缘 -173 与穿廊北端相接。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本殿名牌与悬挂位置必须区分历史实物和导航标签。
  - 实现：主敬殿牌在穿廊梁下悬挂已有源；前殿名牌仍简化。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院中设施各自定位，不能从别院复制铜缸/狮子/香炉。
  - 实现：SouthCourtTrees 另有四个观测树干拟合；其他院设未因此通过。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：2026 年 9 月第一期全景作为选定设备空间版本，不是今日作品陈列。
  - 实现：专用楼面/连续入口及真实展示设备已有。
  - 差异/缺口：未做本轮实机相机匹配。
  - 动作：核入口和设备间穿行；保持单个圆形通道，不把反射当第二洞。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · EXISTING_REQUIRES_BROWSER
  - 源据：固定装修按本房间的对应全景，不从文渊阁/武英殿借用。
  - 实现：前殿圆洞屏风/横竖框、穿廊天花、后殿 R48 格井/圆形轮廓已有。
  - 差异/缺口：细纹和准确重复数属于拟合；主敬殿 18×9 不是测量。
  - 动作：逐对象核天花、隔断与固定屏风，不把现有格井当待新建。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · EXISTING_REQUIRES_BROWSER
  - 源据：有日期的展厅设备，不是帝王家具。
  - 实现：前殿岛墙和一座北侧低柜、穿廊两侧柜/斜托板/挡边、后殿圆展台均已实现。
  - 差异/缺口：不得根据旧输入“未找到室内图”清空展陈或再加通用宝座。
  - 动作：按本区全景核设备类别、数量、朝向及通道；不声称第二期作品已核。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · EXISTING_REQUIRES_BROWSER
  - 源据：灯带/吊轨/吊签和匾有日期的图据。
  - 实现：已有灯带、后殿吊轨及一个空白吊签示例；无虚构书画复制品。
  - 差异/缺口：不是完整当期藏品和标签清单。
  - 动作：核可见器材关系，未确认画作保持空白，不把灯轨当古梁。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · EXISTING_REQUIRES_BROWSER
  - 源据：2026-09 首期书画展设备拓扑。
  - 实现：wenhua-gallery 不是古代寝殿/佛堂。
  - 差异/缺口：当前日期展品布局未确认。
  - 动作：保留目标版本声明；若变更到当期，先补本期完整来源。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：来源支持部分设备；隐藏画作和全库存未知。
  - 实现：没有 generic royal furniture；专用展陈是已有成果。
  - 差异/缺口：须逐物检查仍缺或无据项，不能凭网格数通过。
  - 动作：使用实机对照清单记录物体级差异，保留 source-bound 既有设备。
  - 源：WENHUA-FRONT, WENHUA-ISLAND；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/2

## FC-FD3D76E74D · 文渊阁

三层/双梯/绿色檐柱和分层陈设均已有；南上层连续窗带是可定位的新差异。
原要求：外观明二层、实际含暗层三层；面阔六间，黑瓦绿剪边、绿色檐柱；一层明间及三层内景可核书架、御榻与陈设。；本页未给外景，借文华殿页第7图交叉核对；二层暗层和楼梯未见图。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:384`。绑定：data/zones/outer-east.json#/items/8

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：阁在文华后院、前池一桥；六开间轴线非七开间居中。
  - 实现：已有 exact 六开间 envelope (-186.5,-132.8)、w40.5 d17.9；全部为模型 fit。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：外明二层/内三层、黑瓦绿剪边、绿色檐柱；照片可见两檐轮廓。
  - 实现：两层外壳、上下檐、黑瓦绿边/绿柱/灰山墙都已有。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：六开间，照片上部六个窗组间有绿色墙/柱带；斗栱彩画细部不完整。
  - 实现：上层等距柱与整幅 lattice 带；不能把窗组宽度直接当结构开间。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：南上层为六个分隔窗组而非横贯整栋的连续同纹窗带；下层廊栏和内退门窗独立。
  - 实现：WenyuanPavilion.js:16 两侧生成 uw 宽 lattice_doors 带；R48 未改窗带分组。
  - 差异/缺口：连续带与可见分隔组明确不同；不能因此改柱位、屋顶和楼层。
  - 动作：NEXT：只替换南上层可见表皮为六个独立窗组/绿间隔；用相机控制点拟合宽度，保留后面未知。
  - 源：PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/WenyuanPavilion.js:15-18#upper-wall-window-band; src/scene/palace/special/RemainingOuterHalls.js:1167-1169#column-and-gable-recolour; data/zones/outer-east.json#/items/8
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：正面台阶衔池桥，栏板/望柱只在可见段有图。
  - 实现：现平台/入口安全踏步及既有 wenyuan-pond 桥保留。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：暗层、第三层、两段西端楼梯有文字拓扑；楼梯照片缺失。
  - 实现：R48 已有楼面 y=.5/3.15/5.5、两段楼梯/洞口/护栏；自动上层目的地仍 withheld。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：南上层匾悬在檐下前缘；不能靠导航文字证明原件尺寸。
  - 实现：既有 fitted nameboard 保持出柱前；仍是简化字体和拟合尺寸。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：池桥与阁东黄瓦盔顶碑亭是独立设施。
  - 实现：池桥已渲染；碑亭尚无独立模型。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：官网三层及西端楼梯；一层/三层照片不覆盖第二层楼梯全貌。
  - 实现：三实际楼面、暗层三间空井、双梯及结构支撑已实现。
  - 差异/缺口：米制高度、楼梯尺寸为安全拟合，实机 controller 与视觉不能由 CPU 通过替代。
  - 动作：保留楼层/梯和上层目的地禁用，按原检查范围验证。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/palace/special/RemainingOuterHalls.js:1186-1239#levels-stairs-photo-furniture; data/zones/outer-east.json#/items/8
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · EXISTING_REQUIRES_BROWSER
  - 源据：一层矩形格心固定隔扇；三层固定屏风/顶端横披可见。
  - 实现：已有简化一层 screen post/rail 与各层柜架；精细固定格心和上部横披未完整表达。
  - 差异/缺口：照片上高大框架不是已证床罩；不能生成可进入假房间。
  - 动作：先固定装修分层标注，再对现有格心/横披做局部细化，不搬移楼层。
  - 源：PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/palace/special/RemainingOuterHalls.js:1186-1239#levels-stairs-photo-furniture; data/zones/outer-east.json#/items/8
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · EXISTING_REQUIRES_BROWSER
  - 源据：一层座屏/桌、三层低榻与柜架同层照片有据。
  - 实现：一层 seat+desk、三层 bed base/back/sides 和空柜已有，非待首次摆放。
  - 差异/缺口：细部、准确件数/位置与拍摄时库存未知；历史22/33/22/28不是现柜清单。
  - 动作：对已有每件物体类别/相对位置逐项比，不补历史满架书本。
  - 源：PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/palace/special/RemainingOuterHalls.js:1186-1239#levels-stairs-photo-furniture; data/zones/outer-east.json#/items/8
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：一层照片可见匾联、扇状装饰与桌面器物，三层有织物/地毯局部；日期未知。
  - 实现：代码明确未造 carving/fan art/textiles，避免虚构。
  - 差异/缺口：可以确认图中存在，不足确认全部文字/背面/现存陈列。
  - 动作：只给清楚可见物件建分项证据；先选定照片陈列版本，不添加未知文字或复制图像贴图。
  - 源：PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/palace/special/RemainingOuterHalls.js:1186-1239#levels-stairs-photo-furniture; data/zones/outer-east.json#/items/8
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · EXISTING_REQUIRES_BROWSER
  - 源据：藏书阁与御览空间；历史四库藏书数只支持用途。
  - 实现：三层分级空柜架、御览座/榻，非通用卧室。
  - 差异/缺口：当前书册与陈设日期不明。
  - 动作：保留历史用途与现物未知分离，不以空柜称历史空室。
  - 源：SRC-DDD9C652AEAE, PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/palace/special/RemainingOuterHalls.js:1186-1239#levels-stairs-photo-furniture; data/zones/outer-east.json#/items/8
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：两张室内图各自只覆盖一层明间和三层局部。
  - 实现：R48 既有柜/桌/座/榻，数量是 fit 而不是现存普查。
  - 差异/缺口：旧 baseline “无书架/未造三层”已被增强覆盖。
  - 动作：沿实际 dispatch 逐层取景；只删/改与该层图明显冲突项，保留通行安全件为工程拟合。
  - 源：PHOTO-WENYUAN-FLOOR1, PHOTO-WENYUAN-FLOOR3；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/WenyuanPavilion.js:5-22#buildWenyuanPavilion; src/scene/palace/special/RemainingOuterHalls.js:1158-1239#augmentWenyuanLevels; data/zones/outer-east.json#/items/8

## FC-C8AD5BD621 · 东华门

三券门城台、五间三进深重檐庑殿；中央门面8列9行是本轮窄修
原要求：城楼五间三进深、重檐庑殿、城台三券门；本页外观支持城楼城台层级。；未见楼内照片；建筑页文字提门钉8路9颗，需近景复核不可照其他三门复制。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:385`。绑定：data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22

### exterior：保留 PARTIAL

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：三券门城台、五间三进深重檐庑殿；中央门面8列9行是本轮窄修；院落定位不能以 region 重复计实体。
  - 实现：东华门已有专用结构和单实体声明，其他 region 只语义。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：独立屋顶形式见该对象官页/全图，保留拟合脊坡。
  - 实现：独立 roof builder 已在，不新增屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：逐面柱列/梁枋可见部分；遮树背面未知。
  - 实现：现有柱列/梁与拟合彩画；箭亭20柱不是新成果。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：正面开口与叶面要求必须与本体比较，不能借旁门/其他宫门。
  - 实现：三券门城台、五间三进深重檐庑殿；中央门面8列9行是本轮窄修
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：台阶/月台和入口有外图；具体石材/尺寸未测。
  - 实现：保留平台/现有台阶/门体碰撞；本轮窄修不改变脚下路径。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：廊与城台/院墙接口，不能用有门牌替代空间审查。
  - 实现：已存在所属专用壳与周边连接；未实机对照所有边界。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本门/殿匾具体前后层次，简化字体不是原书法。
  - 实现：已有专用名牌支架/檐间安装；位置仍模型拟合。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院设位置只认本图可见项，树遮处未知。
  - 实现：并非已核院设全清单；本轮无新增通用缸/狮。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `central-door-nine-vertical-stud-rows` · central-door-nine-vertical-stud-rows · IMPLEMENTED_VERIFY_PENDING
  - 源据：Actual official deep-zoom central-door crop shows eight columns and nine rows per leaf. The loaded project door texture has ten rows. Only the two central passage-facing skins are candidates, not other portals or Xihua.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Only central two passage-facing skins show eight-column/nine-row layout from loaded project albedo/normal. Geometry/physics unchanged; inherited hardware/count interruptions, colour/aspect remain uncalibrated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-C4CF78A49BDC；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：入口/门洞可由外图部分观察；楼内/殿内完整图未核。
  - 实现：三券洞已有；上楼未开放、无楼内房间实现。
  - 差异/缺口：外门洞和 viewing-region 不是完整室内实证。
  - 动作：只检查已有通行结构，不能因此略过梁架/顶部和楼内未知任务。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：东华门：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：东华门：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：东华门：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：建筑历史用途有官方文字，当前完整室内陈列未证。
  - 实现：箭亭按武备馆建筑空间，未造通用宝座/武器；两个门不生成寝殿家具。
  - 差异/缺口：正文历史宝座、仪礼用途不能直接当现陈。
  - 动作：补对应目标时期室内来源，保留用途差异；不复制厅堂模板。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：完整内陈未知不等于空房。
  - 实现：这些专用构造没有任意通用帝王家具；结构简化和缺物仍未最终比对。
  - 差异/缺口：必须逐项记录缺失/未证，不以无家具视为室内完成。
  - 动作：核对应实际房间和版本后再增加物体，局部资料不足不影响有据外观。
  - 源：SRC-B5E6885D0B09, SRC-C4CF78A49BDC, PHOTO-DONGHUA-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EastWestCityGate.js:10-94#buildEastWestCityGate; src/scene/zones/ZoneBase.js:326-334#buildCityGate; src/scene/palace/special/DonghuaCentralDoorFront.js:9-100#applyDonghuaCentralDoorFront; data/zones/outer-east.json#/items/21; data/zones/outer-east.json#/items/22

## FC-E09ED30C27 · 内阁大堂

三间南向硬山黄瓦大堂及前垂花门；图可看其尺度等级与院中关系。；四周耳房、两厢、后院与现行室内缺图；命名子房须以正文为依据。
原要求：三间南向硬山黄瓦大堂及前垂花门；图可看其尺度等级与院中关系。；四周耳房、两厢、后院与现行室内缺图；命名子房须以正文为依据。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:386`。绑定：尚无确认绑定

### exterior：保留 IMPLEMENTING

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：官文：南向三间黄瓦硬山；400×323正面照见四红柱、上格下板，中下部被独立前门遮挡。
  - 实现：799390a 主树尚无该主堂；已有独立实施项，不在本报告重复造壳。
  - 差异/缺口：旧D1坐标/17.1×15.5只是可逆拟合，未证屋身尺寸；前门不是第四间。
  - 动作：接续正在进行的主立面有限壳；未知中央下部门洞保持非通行，后/侧/内饰不编造。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：官文：南向三间黄瓦硬山；400×323正面照见四红柱、上格下板，中下部被独立前门遮挡。
  - 实现：799390a 主树尚无该主堂；已有独立实施项，不在本报告重复造壳。
  - 差异/缺口：旧D1坐标/17.1×15.5只是可逆拟合，未证屋身尺寸；前门不是第四间。
  - 动作：接续正在进行的主立面有限壳；未知中央下部门洞保持非通行，后/侧/内饰不编造。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：官文：南向三间黄瓦硬山；400×323正面照见四红柱、上格下板，中下部被独立前门遮挡。
  - 实现：799390a 主树尚无该主堂；已有独立实施项，不在本报告重复造壳。
  - 差异/缺口：旧D1坐标/17.1×15.5只是可逆拟合，未证屋身尺寸；前门不是第四间。
  - 动作：接续正在进行的主立面有限壳；未知中央下部门洞保持非通行，后/侧/内饰不编造。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：官文：南向三间黄瓦硬山；400×323正面照见四红柱、上格下板，中下部被独立前门遮挡。
  - 实现：799390a 主树尚无该主堂；已有独立实施项，不在本报告重复造壳。
  - 差异/缺口：旧D1坐标/17.1×15.5只是可逆拟合，未证屋身尺寸；前门不是第四间。
  - 动作：接续正在进行的主立面有限壳；未知中央下部门洞保持非通行，后/侧/内饰不编造。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：正文独立垂花门、四扇屏门/隔墙、耳房及前后院；照片前景灰瓦门是另一深度实体。
  - 实现：本次仅主堂单体，前门/侧院未建。
  - 差异/缺口：门深与屏门相互位置不充分。
  - 动作：另列前门/屏门 child，不与主堂屋顶或碰撞并体；不要按历史官房清单批量造壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：三间南向硬山黄瓦大堂及前垂花门；图可看其尺度等级与院中关系。；四周耳房、两厢、后院与现行室内缺图；命名子房须以正文为依据。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁大堂：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, SRC-712BB3206158, NEIGE-HALL-PAGE, NEIGE-HALL-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-40EB11CF20 · 内阁大库

砖石库房；正文支持铁柱、铁板窗和红本库/实录库用途。；外观图远且遮挡，不能量化完整立面；室内无公开图证据。
原要求：砖石库房；正文支持铁柱、铁板窗和红本库/实录库用途。；外观图远且遮挡，不能量化完整立面；室内无公开图证据。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:387`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大库是西红本库＋东实录库两座的总称；p53明确两库。官页记砖石、铁柱/铁板窗，图见遮树山墙；2008文章记南窗玻璃变化。
  - 实现：冻结树无两库绑定，不能用一个大堂代表。
  - 差异/缺口：实体数/名称已解，两个现存足迹及全立面窗口仍待注册；照片遮挡不是完全无源。
  - 动作：保留父 FC 并展开两个 child；先核南北窗现状，保留现代变化，不以清代铁窗抹去玻璃。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大库是西红本库＋东实录库两座的总称；p53明确两库。官页记砖石、铁柱/铁板窗，图见遮树山墙；2008文章记南窗玻璃变化。
  - 实现：冻结树无两库绑定，不能用一个大堂代表。
  - 差异/缺口：实体数/名称已解，两个现存足迹及全立面窗口仍待注册；照片遮挡不是完全无源。
  - 动作：保留父 FC 并展开两个 child；先核南北窗现状，保留现代变化，不以清代铁窗抹去玻璃。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大库是西红本库＋东实录库两座的总称；p53明确两库。官页记砖石、铁柱/铁板窗，图见遮树山墙；2008文章记南窗玻璃变化。
  - 实现：冻结树无两库绑定，不能用一个大堂代表。
  - 差异/缺口：实体数/名称已解，两个现存足迹及全立面窗口仍待注册；照片遮挡不是完全无源。
  - 动作：保留父 FC 并展开两个 child；先核南北窗现状，保留现代变化，不以清代铁窗抹去玻璃。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_REGISTRATION
  - 源据：大库是西红本库＋东实录库两座的总称；p53明确两库。官页记砖石、铁柱/铁板窗，图见遮树山墙；2008文章记南窗玻璃变化。
  - 实现：冻结树无两库绑定，不能用一个大堂代表。
  - 差异/缺口：实体数/名称已解，两个现存足迹及全立面窗口仍待注册；照片遮挡不是完全无源。
  - 动作：保留父 FC 并展开两个 child；先核南北窗现状，保留现代变化，不以清代铁窗抹去玻璃。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大库是西红本库＋东实录库两座的总称；p53明确两库。官页记砖石、铁柱/铁板窗，图见遮树山墙；2008文章记南窗玻璃变化。
  - 实现：冻结树无两库绑定，不能用一个大堂代表。
  - 差异/缺口：实体数/名称已解，两个现存足迹及全立面窗口仍待注册；照片遮挡不是完全无源。
  - 动作：保留父 FC 并展开两个 child；先核南北窗现状，保留现代变化，不以清代铁窗抹去玻璃。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：砖石库房；正文支持铁柱、铁板窗和红本库/实录库用途。；外观图远且遮挡，不能量化完整立面；室内无公开图证据。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁大库：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-CDC8F1A98DFC, SRC-E8BFEBD87D71, SRC-4F446FC16E10, SRC-1C946F7B51D3, NEIGE-STORE-PAGE, NEIGE-STORE-PHOTO, NEIGE-TWO-STORES-PAPER, NEIGE-STORE-MEMO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-F608EC3356 · 传心殿

五间三进深硬山黄瓦；正文给出治牲所、景行门、殿后祝版房/神厨/值房及院落尺寸。；图片仅匾额和檐下局部，未见整殿外立面、神位与室内。
原要求：五间三进深硬山黄瓦；正文给出治牲所、景行门、殿后祝版房/神厨/值房及院落尺寸。；图片仅匾额和檐下局部，未见整殿外立面、神位与室内。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:388`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：南向五间三进深黄瓦硬山；匾额有近照。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：南向五间三进深黄瓦硬山；匾额有近照。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：南向五间三进深黄瓦硬山；匾额有近照。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：南向五间三进深黄瓦硬山；匾额有近照。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：4764及2001p21实物匾额近照支持竖匾和红色外框，非整殿。
  - 实现：无本体/匾模型。
  - 差异/缺口：安装精确尺寸、朝向与殿身坐标未完成。
  - 动作：待主殿位置完成后按近照做有限匾框；当前不能用牌匾代替整殿。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020, CHUANXIN-PLAQUE-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：传心殿：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, SRC-DA37AAC94E4D, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-AF36D75128 · 箭亭

五间三进深独立殿、四周廊、20柱；南明间双膝托是本轮窄修
原要求：实为五间三进深独立大殿，黄瓦歇山，四面出廊；图可核正面和院前空间。；有树木遮挡；20柱、卧碣、内设宝座等仅正文支持，室内未核。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:389`。绑定：data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20

### exterior：保留 PARTIAL

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：五间三进深独立殿、四周廊、20柱；南明间双膝托是本轮窄修；院落定位不能以 region 重复计实体。
  - 实现：箭亭已有专用结构和单实体声明，其他 region 只语义。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：独立屋顶形式见该对象官页/全图，保留拟合脊坡。
  - 实现：独立 roof builder 已在，不新增屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：逐面柱列/梁枋可见部分；遮树背面未知。
  - 实现：现有柱列/梁与拟合彩画；箭亭20柱不是新成果。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：正面开口与叶面要求必须与本体比较，不能借旁门/其他宫门。
  - 实现：五间三进深独立殿、四周廊、20柱；南明间双膝托是本轮窄修
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：台阶/月台和入口有外图；具体石材/尺寸未测。
  - 实现：保留平台/现有台阶/门体碰撞；本轮窄修不改变脚下路径。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：廊与城台/院墙接口，不能用有门牌替代空间审查。
  - 实现：已存在所属专用壳与周边连接；未实机对照所有边界。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本门/殿匾具体前后层次，简化字体不是原书法。
  - 实现：已有专用名牌支架/檐间安装；位置仍模型拟合。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院设位置只认本图可见项，树遮处未知。
  - 实现：并非已核院设全清单；本轮无新增通用缸/狮。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `south-central-paired-knees` · south-central-paired-knees · IMPLEMENTED_VERIFY_PENDING
  - 源据：Two broad gray-white knees are visible under the south central beam; the retained model has only straight beams. Only these two observed knees are in scope.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Two observed south central knees, +88 actual triangles; same structural colliders/supports. Full exterior/interior and browser acceptance remain open.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-EDBD42332288；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：入口/门洞可由外图部分观察；楼内/殿内完整图未核。
  - 实现：独立 viewing-region、20柱及五南三北门组已有。
  - 差异/缺口：外门洞和 viewing-region 不是完整室内实证。
  - 动作：只检查已有通行结构，不能因此略过梁架/顶部和楼内未知任务。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：箭亭：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：箭亭：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：箭亭：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：建筑历史用途有官方文字，当前完整室内陈列未证。
  - 实现：箭亭按武备馆建筑空间，未造通用宝座/武器；两个门不生成寝殿家具。
  - 差异/缺口：正文历史宝座、仪礼用途不能直接当现陈。
  - 动作：补对应目标时期室内来源，保留用途差异；不复制厅堂模板。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：完整内陈未知不等于空房。
  - 实现：这些专用构造没有任意通用帝王家具；结构简化和缺物仍未最终比对。
  - 差异/缺口：必须逐项记录缺失/未证，不以无家具视为室内完成。
  - 动作：核对应实际房间和版本后再增加物体，局部资料不足不影响有据外观。
  - 源：SRC-FCB269D5BDDF, SRC-EDBD42332288, PHOTO-ARROW-SOUTH；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/EnclosedPavilions.js:5-90#buildEnclosedPavilion; src/scene/palace/special/ArrowSouthKnees.js:1-61#buildArrowSouthKnees; data/zones/outer-east.json#/items/19; data/zones/outer-east.json#/items/20

## FC-5652FA389B · 文华门

现有五间门殿与三中央门洞；仅右梢间南表面已修浅下槛/粗框
原要求：月台甬路通向文华门；有门外景与匾额彩画专图。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:390`。绑定：data/zones/outer-east.json#/items/0

### exterior：保留 PARTIAL

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：现有五间门殿与三中央门洞；仅右梢间南表面已修浅下槛/粗框；院落定位不能以 region 重复计实体。
  - 实现：文华门已有专用结构和单实体声明，其他 region 只语义。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：独立屋顶形式见该对象官页/全图，保留拟合脊坡。
  - 实现：独立 roof builder 已在，不新增屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：逐面柱列/梁枋可见部分；遮树背面未知。
  - 实现：现有柱列/梁与拟合彩画；箭亭20柱不是新成果。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_IMPLEMENTATION
  - 源据：正面开口与叶面要求必须与本体比较，不能借旁门/其他宫门。
  - 实现：现有五间门殿与三中央门洞；仅右梢间南表面已修浅下槛/粗框
  - 差异/缺口：右梢间现有粗框/黑凹面明确尚缺官图可见红色斜格，左端与北面未改；不是完整修好。
  - 动作：NEXT：只在已定位右梢间补可见斜格形态；保留隐藏扇数未知及不通行碰撞，不镜像扩到左/北面。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：台阶/月台和入口有外图；具体石材/尺寸未测。
  - 实现：保留平台/现有台阶/门体碰撞；本轮窄修不改变脚下路径。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：廊与城台/院墙接口，不能用有门牌替代空间审查。
  - 实现：已存在所属专用壳与周边连接；未实机对照所有边界。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本门/殿匾具体前后层次，简化字体不是原书法。
  - 实现：已有专用名牌支架/檐间安装；位置仍模型拟合。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院设位置只认本图可见项，树遮处未知。
  - 实现：并非已核院设全清单；本轮无新增通用缸/狮。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `south-right-end-window-lower-panel` · south-right-end-window-lower-panel · IMPLEMENTED_VERIFY_PENDING
  - 源据：The photo-right south end bay has a pale lower panel and upper red window frame; the retained end wall is uninterrupted red. Only the observed local-negative-X front surface is in scope; fine grille counts remain unresolved.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Only photo-right south end surface: pale lower panel and coarse red frame/recess, +106 triangles; fine red grille remains visibly missing and is NOT accepted.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-7C610E43BDA2；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：入口/门洞可由外图部分观察；楼内/殿内完整图未核。
  - 实现：通廊柱网、三中门洞及各自台阶已有。
  - 差异/缺口：外门洞和 viewing-region 不是完整室内实证。
  - 动作：只检查已有通行结构，不能因此略过梁架/顶部和楼内未知任务。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：文华门：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：文华门：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：文华门：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：建筑历史用途有官方文字，当前完整室内陈列未证。
  - 实现：箭亭按武备馆建筑空间，未造通用宝座/武器；两个门不生成寝殿家具。
  - 差异/缺口：正文历史宝座、仪礼用途不能直接当现陈。
  - 动作：补对应目标时期室内来源，保留用途差异；不复制厅堂模板。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：完整内陈未知不等于空房。
  - 实现：这些专用构造没有任意通用帝王家具；结构简化和缺物仍未最终比对。
  - 差异/缺口：必须逐项记录缺失/未证，不以无家具视为室内完成。
  - 动作：核对应实际房间和版本后再增加物体，局部资料不足不影响有据外观。
  - 源：SRC-61B6A67B7085, SRC-7C610E43BDA2, PHOTO-WENHUA-GATE；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtGates.js:5-17#buildSouthCourtGate; src/scene/palace/special/WenhuaGateSouthWindows.js:11-88#applyWenhuaGateSouthWindows; data/zones/outer-east.json#/items/0

## FC-B7C67C602B · 主敬殿

已有专用工字殿/展陈，接续 R39/R48；不重建、不回退为无图空壳。
原要求：工字殿的后殿，形制近似前殿而进深略浅；以穿廊相接。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:391`。绑定：data/zones/outer-east.json#/items/3

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：官网工字形前殿/穿廊/后殿关系；地图不是米制定位。
  - 实现：主敬殿已有 rear 专用声明与 exact-profile，非缺壳。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：前殿五间三进深黄瓦歇山；后殿稍浅；穿廊独立低屋顶，不能混为同一殿屋面。
  - 实现：SouthCourtHalls 使用保留歇山 hall 或旋转 gable 穿廊屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：官网开间与既有独立柱列，三交六椀是前殿要求，不自动复制到穿廊。
  - 实现：沿用五开间 hall 与单跨穿廊拟合；非实测彩画/斗栱。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：本对象的前后开口及穿廊连接；其余立面仍须分方向观察。
  - 实现：正殿/后殿前后 portal 已有；穿廊两端开通、侧墙连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：月台甬路和共有地坪关系，尺寸不是测绘。
  - 实现：三个对象楼面均 1.2；相接内阶藏于连接台基下，安全连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：前后殿通过穿廊连续连接；其端部不是横墙或独立台阶。
  - 实现：文华前殿后缘 -190.5 与穿廊南端、后殿前缘 -173 与穿廊北端相接。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本殿名牌与悬挂位置必须区分历史实物和导航标签。
  - 实现：主敬殿牌在穿廊梁下悬挂已有源；前殿名牌仍简化。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院中设施各自定位，不能从别院复制铜缸/狮子/香炉。
  - 实现：SouthCourtTrees 另有四个观测树干拟合；其他院设未因此通过。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：2026 年 9 月第一期全景作为选定设备空间版本，不是今日作品陈列。
  - 实现：专用楼面/连续入口及真实展示设备已有。
  - 差异/缺口：未做本轮实机相机匹配。
  - 动作：核入口和设备间穿行；保持单个圆形通道，不把反射当第二洞。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · EXISTING_REQUIRES_BROWSER
  - 源据：固定装修按本房间的对应全景，不从文渊阁/武英殿借用。
  - 实现：前殿圆洞屏风/横竖框、穿廊天花、后殿 R48 格井/圆形轮廓已有。
  - 差异/缺口：细纹和准确重复数属于拟合；主敬殿 18×9 不是测量。
  - 动作：逐对象核天花、隔断与固定屏风，不把现有格井当待新建。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · EXISTING_REQUIRES_BROWSER
  - 源据：有日期的展厅设备，不是帝王家具。
  - 实现：前殿岛墙和一座北侧低柜、穿廊两侧柜/斜托板/挡边、后殿圆展台均已实现。
  - 差异/缺口：不得根据旧输入“未找到室内图”清空展陈或再加通用宝座。
  - 动作：按本区全景核设备类别、数量、朝向及通道；不声称第二期作品已核。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · EXISTING_REQUIRES_BROWSER
  - 源据：灯带/吊轨/吊签和匾有日期的图据。
  - 实现：已有灯带、后殿吊轨及一个空白吊签示例；无虚构书画复制品。
  - 差异/缺口：不是完整当期藏品和标签清单。
  - 动作：核可见器材关系，未确认画作保持空白，不把灯轨当古梁。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · EXISTING_REQUIRES_BROWSER
  - 源据：2026-09 首期书画展设备拓扑。
  - 实现：wenhua-gallery 不是古代寝殿/佛堂。
  - 差异/缺口：当前日期展品布局未确认。
  - 动作：保留目标版本声明；若变更到当期，先补本期完整来源。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：来源支持部分设备；隐藏画作和全库存未知。
  - 实现：没有 generic royal furniture；专用展陈是已有成果。
  - 差异/缺口：须逐物检查仍缺或无据项，不能凭网格数通过。
  - 动作：使用实机对照清单记录物体级差异，保留 source-bound 既有设备。
  - 源：ZHUJING-CEILING, ZHUJING-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/RemainingOuterHalls.js:1427-1470#augmentZhujingPhotoDetails; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/3

## FC-4D5AAFEDA4 · 本仁殿

院面已有独立照片拟合，室内缺完整可定位图；不能重做旧成果。
原要求：文华殿院落东配殿；名称与方位由正文确认。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:392`。绑定：data/zones/outer-east.json#/items/4

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：本仁殿是文华院东配殿，不能按源码分区名归错院。
  - 实现：已有旋转配殿 exact-profile。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：现存屋顶与完整背面还需独立观察，前景片段不证整屋。
  - 实现：沿用既有屋顶，不以正面细化报屋面通过。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：自身2022院落全景支持前立面；本仁遮挡，集义可见五组。
  - 实现：R48 自有照片立面增强已执行。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：自有照片的石下槛/红格心，不能把另侧五组叶数当本站测量。
  - 实现：已有石下槛、四叶重复拟合、菱形格心、中央折叶通行拟合。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：台基/门槛和院内路径须按本殿看。
  - 实现：原台基保留；可见门叶/柱薄碰撞已在。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：配殿与院墙/前后主殿关系须分实例。
  - 实现：配殿真实同级 scene object 不否认语义院落父级。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：原标签不是牌匾真迹；已有独立 nameboard 层。
  - 实现：R49 已有 source-guided 名牌校正，不重复实施。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：自身院面设施未有全量普查。
  - 实现：未加入任意同款通用院设。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：本仁殿：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：本仁殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：本仁殿：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：本仁殿：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：本仁殿：已有主体/父页来源，但未提供可确认的本项“宗教/藏书/寝居/展厅用途”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作宗教/藏书/寝居/展厅用途已经核验。
  - 差异/缺口：宗教/藏书/寝居/展厅用途的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起宗教/藏书/寝居/展厅用途的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未找到属于本殿当前房间的内陈照片。
  - 实现：继承 empty shell，不是已证空室；R48 自述室内 EVIDENCE_BLOCKED。
  - 差异/缺口：不从文华主殿展柜或另一配殿借陈设。
  - 动作：先补本殿室内整体和侧向图；保留外观成果与未知内陈。
  - 源：SRC-61B6A67B7085, BENREN-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/4

## FC-BEE00AE333 · 集义殿

院面已有独立照片拟合，室内缺完整可定位图；不能重做旧成果。
原要求：文华殿院落西配殿；名称与方位由正文确认。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:393`。绑定：data/zones/outer-east.json#/items/5

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：集义殿是文华院西配殿，不能按源码分区名归错院。
  - 实现：已有旋转配殿 exact-profile。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的平面/朝向/院落连接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：现存屋顶与完整背面还需独立观察，前景片段不证整屋。
  - 实现：沿用既有屋顶，不以正面细化报屋面通过。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：自身2022院落全景支持前立面；本仁遮挡，集义可见五组。
  - 实现：R48 自有照片立面增强已执行。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：自有照片的石下槛/红格心，不能把另侧五组叶数当本站测量。
  - 实现：已有石下槛、四叶重复拟合、菱形格心、中央折叶通行拟合。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：台基/门槛和院内路径须按本殿看。
  - 实现：原台基保留；可见门叶/柱薄碰撞已在。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：配殿与院墙/前后主殿关系须分实例。
  - 实现：配殿真实同级 scene object 不否认语义院落父级。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：原标签不是牌匾真迹；已有独立 nameboard 层。
  - 实现：R49 已有 source-guided 名牌校正，不重复实施。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：自身院面设施未有全量普查。
  - 实现：未加入任意同款通用院设。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：集义殿：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：集义殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：集义殿：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：集义殿：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：集义殿：已有主体/父页来源，但未提供可确认的本项“宗教/藏书/寝居/展厅用途”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作宗教/藏书/寝居/展厅用途已经核验。
  - 差异/缺口：宗教/藏书/寝居/展厅用途的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起宗教/藏书/寝居/展厅用途的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未找到属于本殿当前房间的内陈照片。
  - 实现：继承 empty shell，不是已证空室；R48 自述室内 EVIDENCE_BLOCKED。
  - 差异/缺口：不从文华主殿展柜或另一配殿借陈设。
  - 动作：先补本殿室内整体和侧向图；保留外观成果与未知内陈。
  - 源：SRC-61B6A67B7085, JIYI-FRONT；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/RemainingOuterHalls.js:1394-1425#augmentWenhuaCompanionFacade; data/zones/outer-east.json#/items/5

## FC-0B08F51957 · 文华殿穿廊

已有专用工字殿/展陈，接续 R39/R48；不重建、不回退为无图空壳。
原要求：连接文华殿与主敬殿，组成工字平面。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:394`。绑定：data/zones/outer-east.json#/items/23

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：官网工字形前殿/穿廊/后殿关系；地图不是米制定位。
  - 实现：文华殿穿廊已有 connector 专用声明与 exact-profile，非缺壳。
  - 差异/缺口：canonical 已采用 items/23 与 AUX-1DA0AE7EB391 同体绑定，不能再当缺壳或新登记成果；视觉仍未验收。
  - 动作：保留现有 items/23 与 architecture id outer-east/wenhua-connector 绑定和 AUX 原任务，只补实际同视角对照。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · EXISTING_REQUIRES_BROWSER
  - 源据：前殿五间三进深黄瓦歇山；后殿稍浅；穿廊独立低屋顶，不能混为同一殿屋面。
  - 实现：SouthCourtHalls 使用保留歇山 hall 或旋转 gable 穿廊屋顶。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · EXISTING_REQUIRES_BROWSER
  - 源据：官网开间与既有独立柱列，三交六椀是前殿要求，不自动复制到穿廊。
  - 实现：沿用五开间 hall 与单跨穿廊拟合；非实测彩画/斗栱。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · EXISTING_REQUIRES_BROWSER
  - 源据：本对象的前后开口及穿廊连接；其余立面仍须分方向观察。
  - 实现：正殿/后殿前后 portal 已有；穿廊两端开通、侧墙连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：月台甬路和共有地坪关系，尺寸不是测绘。
  - 实现：三个对象楼面均 1.2；相接内阶藏于连接台基下，安全连续。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：前后殿通过穿廊连续连接；其端部不是横墙或独立台阶。
  - 实现：文华前殿后缘 -190.5 与穿廊南端、后殿前缘 -173 与穿廊北端相接。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · EXISTING_REQUIRES_BROWSER
  - 源据：本殿名牌与悬挂位置必须区分历史实物和导航标签。
  - 实现：主敬殿牌在穿廊梁下悬挂已有源；前殿名牌仍简化。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：院中设施各自定位，不能从别院复制铜缸/狮子/香炉。
  - 实现：SouthCourtTrees 另有四个观测树干拟合；其他院设未因此通过。
  - 差异/缺口：源码存在不等于外观一致；隐藏方向、尺寸与拍摄年代未全部证成。
  - 动作：保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。
  - 源：SRC-61B6A67B7085；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · EXISTING_REQUIRES_BROWSER
  - 源据：2026 年 9 月第一期全景作为选定设备空间版本，不是今日作品陈列。
  - 实现：专用楼面/连续入口及真实展示设备已有。
  - 差异/缺口：未做本轮实机相机匹配。
  - 动作：核入口和设备间穿行；保持单个圆形通道，不把反射当第二洞。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · EXISTING_REQUIRES_BROWSER
  - 源据：固定装修按本房间的对应全景，不从文渊阁/武英殿借用。
  - 实现：前殿圆洞屏风/横竖框、穿廊天花、后殿 R48 格井/圆形轮廓已有。
  - 差异/缺口：细纹和准确重复数属于拟合；主敬殿 18×9 不是测量。
  - 动作：逐对象核天花、隔断与固定屏风，不把现有格井当待新建。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · EXISTING_REQUIRES_BROWSER
  - 源据：有日期的展厅设备，不是帝王家具。
  - 实现：前殿岛墙和一座北侧低柜、穿廊两侧柜/斜托板/挡边、后殿圆展台均已实现。
  - 差异/缺口：不得根据旧输入“未找到室内图”清空展陈或再加通用宝座。
  - 动作：按本区全景核设备类别、数量、朝向及通道；不声称第二期作品已核。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · EXISTING_REQUIRES_BROWSER
  - 源据：灯带/吊轨/吊签和匾有日期的图据。
  - 实现：已有灯带、后殿吊轨及一个空白吊签示例；无虚构书画复制品。
  - 差异/缺口：不是完整当期藏品和标签清单。
  - 动作：核可见器材关系，未确认画作保持空白，不把灯轨当古梁。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · EXISTING_REQUIRES_BROWSER
  - 源据：2026-09 首期书画展设备拓扑。
  - 实现：wenhua-gallery 不是古代寝殿/佛堂。
  - 差异/缺口：当前日期展品布局未确认。
  - 动作：保留目标版本声明；若变更到当期，先补本期完整来源。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · EXISTING_REQUIRES_BROWSER
  - 源据：来源支持部分设备；隐藏画作和全库存未知。
  - 实现：没有 generic royal furniture；专用展陈是已有成果。
  - 差异/缺口：须逐物检查仍缺或无据项，不能凭网格数通过。
  - 动作：使用实机对照清单记录物体级差异，保留 source-bound 既有设备。
  - 源：WENHUA-CONNECTOR；代码：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23

## FC-F23B7824D4 · 文渊阁碑亭

位于阁东，黄琉璃瓦盔顶；内立御制文渊阁记碑。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：位于阁东，黄琉璃瓦盔顶；内立御制文渊阁记碑。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:395`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：阁东碑亭，黄琉璃瓦盔顶，御制文渊阁记碑；正面照片右缘显示部分黄顶/檐柱。
  - 实现：冻结树无专用碑亭实体；池桥不是碑亭。
  - 差异/缺口：现存身份与局部屋顶有源；遮挡后的全足迹/背面、碑体尺度未定。
  - 动作：追加独立子项注册，查自有近景后做可见部分；不将半张阁图升级为全亭验收。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：阁东碑亭，黄琉璃瓦盔顶，御制文渊阁记碑；正面照片右缘显示部分黄顶/檐柱。
  - 实现：冻结树无专用碑亭实体；池桥不是碑亭。
  - 差异/缺口：现存身份与局部屋顶有源；遮挡后的全足迹/背面、碑体尺度未定。
  - 动作：追加独立子项注册，查自有近景后做可见部分；不将半张阁图升级为全亭验收。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：位于阁东，黄琉璃瓦盔顶；内立御制文渊阁记碑。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：保留原 ID，分离现存/历史内容，先登记实体边界与控制点；只实现有证的子范围。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：阁东碑亭，黄琉璃瓦盔顶，御制文渊阁记碑；正面照片右缘显示部分黄顶/檐柱。
  - 实现：冻结树无专用碑亭实体；池桥不是碑亭。
  - 差异/缺口：现存身份与局部屋顶有源；遮挡后的全足迹/背面、碑体尺度未定。
  - 动作：追加独立子项注册，查自有近景后做可见部分；不将半张阁图升级为全亭验收。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · SOURCE_PRESENT_REGISTRATION
  - 源据：阁东碑亭，黄琉璃瓦盔顶，御制文渊阁记碑；正面照片右缘显示部分黄顶/檐柱。
  - 实现：冻结树无专用碑亭实体；池桥不是碑亭。
  - 差异/缺口：现存身份与局部屋顶有源；遮挡后的全足迹/背面、碑体尺度未定。
  - 动作：追加独立子项注册，查自有近景后做可见部分；不将半张阁图升级为全亭验收。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：官方文字可证亭内御制记碑。
  - 实现：无碑亭/碑体可运行绑定。
  - 差异/缺口：碑刻外形/字面及准确位置缺近景；碑不是可移动通用家具。
  - 动作：补带题注碑体与亭内梁架图，保留固定设施任务，不能直接 N/A。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：位于阁东，黄琉璃瓦盔顶；内立御制文渊阁记碑。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：文渊阁碑亭：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-DDD9C652AEAE, SRC-60CF274F012A, PHOTO-WENYUAN-FRONT；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-905A51A8BC · 治牲所

传心殿院落南端，坐南朝北，五间三进深、黄瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：传心殿院落南端，坐南朝北，五间三进深、黄瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:396`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：南端朝北五间三进深黄瓦硬山；弹注歇山与正文/论文冲突。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：南端朝北五间三进深黄瓦硬山；弹注歇山与正文/论文冲突。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：南端朝北五间三进深黄瓦硬山；弹注歇山与正文/论文冲突。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：南端朝北五间三进深黄瓦硬山；弹注歇山与正文/论文冲突。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：治牲所：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-CE6964B462 · 景行门

传心殿南侧，面南三间、黄瓦悬山，明间前后开门。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：传心殿南侧，面南三间、黄瓦悬山，明间前后开门。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:397`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：殿南三间黄瓦悬山，明间南北开门；不是院东琉璃门。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：殿南三间黄瓦悬山，明间南北开门；不是院东琉璃门。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：殿南三间黄瓦悬山，明间南北开门；不是院东琉璃门。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_REGISTRATION
  - 源据：正文/2001p21明确明间前后开门；p22东琉璃门有清楚题注但不是景行门。
  - 实现：无本门实体。
  - 差异/缺口：景行门完整立面和门厅细部未见确认图。
  - 动作：可保留中央南北通口拓扑；先注册本门而不是复制东墙琉璃门。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：殿南三间黄瓦悬山，明间南北开门；不是院东琉璃门。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：景行门：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-73FC3BE9A7 · 传心殿祝版房

殿后三间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：殿后三间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:398`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，不能与内阁祝版房混同。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，不能与内阁祝版房混同。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，不能与内阁祝版房混同。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，不能与内阁祝版房混同。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：传心殿祝版房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-D852D8A192 · 传心殿神厨

殿后三间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：殿后三间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:399`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，与祝版房分别登记。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，与祝版房分别登记。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，与祝版房分别登记。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后三间，与祝版房分别登记。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：传心殿神厨：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-92B6D8420A · 传心殿值房

殿后五间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：殿后五间，具体朝向与尺寸未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:400`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后五间，具体方向及平面未冻定。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后五间，具体方向及平面未冻定。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后五间，具体方向及平面未冻定。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：主殿后五间，具体方向及平面未冻定。院整体100×25m、南北顺序及后部3/3/5有源。
  - 实现：冻结树无对应实体；旧(-230,-190)候选与现墙/水系范围冲突。
  - 差异/缺口：来源不是空白，主要前置是现状位置注册与历史/现代区分。
  - 动作：先解文华东墙、东西错位琉璃门、河道的共同控制；不可机械套100×25或把六对象总标无源。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：历史祭告用途、牌位和九案/祭器记述，不是现代室内照片。
  - 实现：无现代内陈实现；不能按文献摆满。
  - 差异/缺口：已知用途但当前房间总览/陈列日期缺失。
  - 动作：保留历史说明，单列现代内饰缺图；来源现有不等于准许虚构神位布置。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：传心殿值房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-3B05D29BA57B, SRC-13ED62D11BFD, SRC-995DB0405D26, SRC-46F4A3E6F0DD, SRC-FCFA7921E97E, SRC-712BB3206158, CHUANXIN-PAGE, CHUANXIN-PAPER20, CHUANXIN-PAPER21, CHUANXIN-PAPER22, HARD-GABLES-2020；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-F539E5D64D · 内阁汉票签房

大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:401`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东厢，坐东面西三间；中、北、南三间分别有不同文书用途。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁汉票签房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-32A68E9C3E · 内阁蒙古堂

大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:402`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西厢，坐西面东三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁蒙古堂：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-2C486A3479 · 内阁汉本堂

汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:403`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：汉票签房之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁汉本堂：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-4A84B24027 · 内阁满本堂

蒙古堂之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：蒙古堂之南，向南面城垣三间。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:404`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · HISTORICAL_NOT_CURRENT
  - 源据：官网词条“满本堂”释义明确原在内阁大堂院内、现不存；同释义在大库页重复。
  - 实现：冻结树没有本堂壳；canonical 已设 historical_location 与禁止建当代实体策略。
  - 差异/缺口：原要求中的历史三间房关系必须保留，但不能成为当代实体。
  - 动作：canonical 已采用 historical_location / DO_NOT_CREATE_CURRENT_BUILDING；保留 FC、历史定位和全部旧任务，不重复当新修正，也不授予 ACCEPTED。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · HISTORICAL_NOT_CURRENT
  - 源据：现不存的办事机构，只能保留历史职能/布置研究。
  - 实现：无现存房间可据此建设。
  - 差异/缺口：不构造现代满本堂室内。
  - 动作：历史研究任务继续保留，现状实现范围写明确排除理由，不能删 ID。
  - 源：SRC-9BBFAEBC1FAF, SRC-CDC8F1A98DFC, NEIGE-HALL-PAGE, NEIGE-STORE-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-15E0B02776 · 内阁祝版房

满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:405`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：满本堂西侧；不可与传心殿祝版房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁祝版房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-12AA4B4366 · 内阁满票签房

大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:406`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂东耳房四间，灰瓦硬山；不可与东厢汉票签房混同。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-93081154E4 · 内阁稽查房

大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:407`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：文字证明的身份/拓扑与局部图不等于现存精确足迹；无模型不是无来源。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂西耳房四间，灰瓦硬山。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁稽查房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-DA0F70A4C4 · 内阁典籍厅

大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:408`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁典籍厅：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-6555093DAA · 内阁满票签档子房

大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
原要求：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:409`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。 官页正文是职能/历史院落关系，不能孤立判现存。
  - 实现：在冻结树的声明/专用注册中未找到该单体可运行绑定。
  - 差异/缺口：连独立实体边界尚未证明，不能按两个职能名字直接造两栋。
  - 动作：把历史职能对应到现存实体/房间；确定仍存与边界后再建，不从同页名称自动生成独立壳。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：大堂后斋宿区之东；正文确认名称，但独立形体边界未给。；父页可确认名称/关系；完整立面、屋面细节、尺寸及室内尚缺专门图证。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：内阁满票签档子房：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-9BBFAEBC1FAF, SRC-BCC3E48698C1, NEIGE-HALL-PAGE；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-4591AC1E97 · 文渊阁池桥

已有水系子实体，室内 canonical 已 NOT_APPLICABLE；不得创建家具任务或重复桥。
原要求：文渊阁前方池上石桥，与池岸栏板共同构成前庭。；桥面、桥拱、栏板纹样和池岸尺寸需要近景；室内不适用。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:410`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · EXISTING_REQUIRES_BROWSER
  - 源据：阁前方池单桥及可见石栏/台阶在正面官图可观察。
  - 实现：已有 southWater.bridges[id=wenyuan-pond]，13.2×3.4/crest .18 为保留 fit；有 walkables structureId。
  - 差异/缺口：canonical 已有 runtimeComponentBindings，并非缺桥或待首次绑定；精确栏纹/坡拱/池岸仍未验收。
  - 动作：保留现水系 child 与 walkables 绑定和全部拟合尺寸；按同视角核栏板/桥面，勿再造第二桥或重复报登记成果。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：本项是无封闭房间的室外石桥，不是楼殿。
  - 实现：仅桥面/桥体/栏杆设施。
  - 差异/缺口：楼层屋顶、殿柱门窗/殿匾不适用；若有桥刻/栏柱仍归可见构件，不可丢。
  - 动作：保留该特征原 ID，以角色说明不适用；桥身及栏板仍在 E4/E7 核查。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：本项是无封闭房间的室外石桥，不是楼殿。
  - 实现：仅桥面/桥体/栏杆设施。
  - 差异/缺口：楼层屋顶、殿柱门窗/殿匾不适用；若有桥刻/栏柱仍归可见构件，不可丢。
  - 动作：保留该特征原 ID，以角色说明不适用；桥身及栏板仍在 E4/E7 核查。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：本项是无封闭房间的室外石桥，不是楼殿。
  - 实现：仅桥面/桥体/栏杆设施。
  - 差异/缺口：楼层屋顶、殿柱门窗/殿匾不适用；若有桥刻/栏柱仍归可见构件，不可丢。
  - 动作：保留该特征原 ID，以角色说明不适用；桥身及栏板仍在 E4/E7 核查。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · EXISTING_REQUIRES_BROWSER
  - 源据：阁前方池单桥及可见石栏/台阶在正面官图可观察。
  - 实现：已有 southWater.bridges[id=wenyuan-pond]，13.2×3.4/crest .18 为保留 fit；有 walkables structureId。
  - 差异/缺口：canonical 已有 runtimeComponentBindings，并非缺桥或待首次绑定；精确栏纹/坡拱/池岸仍未验收。
  - 动作：保留现水系 child 与 walkables 绑定和全部拟合尺寸；按同视角核栏板/桥面，勿再造第二桥或重复报登记成果。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · EXISTING_REQUIRES_BROWSER
  - 源据：阁前方池单桥及可见石栏/台阶在正面官图可观察。
  - 实现：已有 southWater.bridges[id=wenyuan-pond]，13.2×3.4/crest .18 为保留 fit；有 walkables structureId。
  - 差异/缺口：canonical 已有 runtimeComponentBindings，并非缺桥或待首次绑定；精确栏纹/坡拱/池岸仍未验收。
  - 动作：保留现水系 child 与 walkables 绑定和全部拟合尺寸；按同视角核栏板/桥面，勿再造第二桥或重复报登记成果。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：本项是无封闭房间的室外石桥，不是楼殿。
  - 实现：仅桥面/桥体/栏杆设施。
  - 差异/缺口：楼层屋顶、殿柱门窗/殿匾不适用；若有桥刻/栏柱仍归可见构件，不可丢。
  - 动作：保留该特征原 ID，以角色说明不适用；桥身及栏板仍在 E4/E7 核查。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · EXISTING_REQUIRES_BROWSER
  - 源据：阁前方池单桥及可见石栏/台阶在正面官图可观察。
  - 实现：已有 southWater.bridges[id=wenyuan-pond]，13.2×3.4/crest .18 为保留 fit；有 walkables structureId。
  - 差异/缺口：canonical 已有 runtimeComponentBindings，并非缺桥或待首次绑定；精确栏纹/坡拱/池岸仍未验收。
  - 动作：保留现水系 child 与 walkables 绑定和全部拟合尺寸；按同视角核栏板/桥面，勿再造第二桥或重复报登记成果。
  - 源：SRC-D45E386F561E, PHOTO-WENYUAN-FRONT；代码：src/scene/palace/special/SouthWaterSystem.js:41-51#southWaterProfile; src/scene/palace/special/SouthWaterSystem.js#buildSouthWaterSystem
### interior：保留 NOT_APPLICABLE

No current enclosed interior: inspect physical surfaces/exterior or historical absence; no furniture generation.


## FC-C640AE8651 · 南三所

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：并列东中西三所，每所三进；撷芳殿不应被当作另一个西北建筑，也不等于宁寿花园撷芳亭。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:411`。绑定：data/zones/outer-east.json#/items/18

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：三院九主殿和 EXPAND-04 所有附属项是父级汇总范围。
  - 实现：items/18 是 region；六壳/一总门/墙各自存在，不能把父项加成第十殿。
  - 差异/缺口：父项不能随六壳局部改动关闭。
  - 动作：逐子项汇总所有14类要求及 EXPAND-04；保留父任务直到残余全部说明。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · AGGREGATE_OR_NOT_APPLICABLE
  - 源据：院落父项不另有统一室内。
  - 实现：没有父级通用 room 或家具。
  - 差异/缺口：所属房间仍有未知，不能父项另造通用内陈。
  - 动作：把本条室内要求下钻到每个现存子房；父任务保留汇总状态。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:345-356#buildRegion; src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/18

## FC-B0B56A63EE · 南三所共用宫门

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：同项名：南三所宫门；方向/用途工作名，非牌匾名；三间绿瓦歇山；三所各自另有南端琉璃门，不能只留一扇总门。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:412`。绑定：data/zones/outer-east.json#/items/10

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：官方三间一进深绿瓦歇山总门，三所各自南琉璃门是另外三对象。
  - 实现：items/10 现是 CourtKit.gate wall 变体，不是三间歇山门殿；不是完全缺门。
  - 差异/缺口：门殿体型差异明确但现壳位置/完整立面及通口尺寸未注册。
  - 动作：先确认总门与各所门坐标，后专用替换 wall 变体；保留通行，勿把三所门合并为一个总门。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：官方三间一进深绿瓦歇山总门，三所各自南琉璃门是另外三对象。
  - 实现：items/10 现是 CourtKit.gate wall 变体，不是三间歇山门殿；不是完全缺门。
  - 差异/缺口：门殿体型差异明确但现壳位置/完整立面及通口尺寸未注册。
  - 动作：先确认总门与各所门坐标，后专用替换 wall 变体；保留通行，勿把三所门合并为一个总门。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：官方三间一进深绿瓦歇山总门，三所各自南琉璃门是另外三对象。
  - 实现：items/10 现是 CourtKit.gate wall 变体，不是三间歇山门殿；不是完全缺门。
  - 差异/缺口：门殿体型差异明确但现壳位置/完整立面及通口尺寸未注册。
  - 动作：先确认总门与各所门坐标，后专用替换 wall 变体；保留通行，勿把三所门合并为一个总门。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_REGISTRATION
  - 源据：官方三间一进深绿瓦歇山总门，三所各自南琉璃门是另外三对象。
  - 实现：items/10 现是 CourtKit.gate wall 变体，不是三间歇山门殿；不是完全缺门。
  - 差异/缺口：门殿体型差异明确但现壳位置/完整立面及通口尺寸未注册。
  - 动作：先确认总门与各所门坐标，后专用替换 wall 变体；保留通行，勿把三所门合并为一个总门。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/10
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/10
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/10
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/10
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“分隔/开口/柱网/楼层/台阶/地面”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作分隔/开口/柱网/楼层/台阶/地面已经核验。
  - 差异/缺口：分隔/开口/柱网/楼层/台阶/地面的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起分隔/开口/柱网/楼层/台阶/地面的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“宗教/藏书/寝居/展厅用途”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作宗教/藏书/寝居/展厅用途已经核验。
  - 差异/缺口：门厅梁架仍需核，不因没有家具略过。
  - 动作：仅挂起宗教/藏书/寝居/展厅用途的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：南三所共用宫门：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/zones/ZoneBase.js:246-257#buildGate; src/scene/palace/kit.js:268-344#gate; data/zones/outer-east.json#/items/10

## FC-2E6207278C · 南三所东所前殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:413`。绑定：data/zones/outer-east.json#/items/16

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所东所前殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所东所前殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所东所前殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所东所前殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所东所前殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/16

## FC-D2A4662D07 · 南三所东所中殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:414`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所东所中殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所东所中殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所东所中殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所东所中殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所东所中殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation

## FC-4642F5088E · 南三所东所后殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:415`。绑定：data/zones/outer-east.json#/items/17

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所东所后殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所东所后殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所东所后殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所东所后殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所东所后殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/17

## FC-C1914091EC · 南三所中所前殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:416`。绑定：data/zones/outer-east.json#/items/14

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所中所前殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所中所前殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所中所前殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所中所前殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所中所前殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/14

## FC-B875FF665E · 南三所中所中殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:417`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_REGISTRATION
  - 源据：官图7996题注中所中殿：五间绿瓦硬山、红门/格窗/白下部、低灰台基。
  - 实现：尚未确认其对应六壳哪一个；不要把现“后殿撷芳殿”自动当它。
  - 差异/缺口：外观源清楚，但物理位置/身份是前置，不是缺外观照片。
  - 动作：登记该专图只绑定本 FC；取得现代足迹控制后再做五间立面有界修正。
  - 源：NANSANSUO-MIDDLE-HALL, NANSANSUO-PAGE；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所中所中殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所中所中殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所中所中殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所中所中殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation

## FC-5E024932AE · 南三所中所后殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。 官刊有“南三所中所撷芳殿外景”图题，但本次未找到将撷芳殿精确等同于此后殿的官方文字；保持待核，不合并。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:418`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation

## FC-172C8CBF68 · 南三所西所前殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:419`。绑定：data/zones/outer-east.json#/items/12

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所西所前殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所西所前殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、前殿三间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所西所前殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所西所前殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所西所前殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/12

## FC-D4F3E359DE · 南三所西所中殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:420`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所西所中殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所西所中殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条无已确认单体绑定。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所西所中殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所西所中殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所西所中殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation

## FC-3F2EBD1B02 · 南三所西所后殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：方向/用途工作名，非牌匾名；前殿三间，中后殿五间，绿瓦硬山；东西配殿各三间应在后续执行台账逐栋展开。；公开资料的建筑沿革与陈设记述须和现存照片分开；文件URL中的年月不代表实拍日期。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:421`。绑定：data/zones/outer-east.json#/items/13

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所西所后殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所西所后殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所西所后殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所西所后殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所西所后殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/13

## FC-33770DFDD3 · 銮驾库

官方叙述包含历史已失房屋；现状几何须凭实际图像核定。
原要求：官方叙述包含历史已失房屋；现状几何须凭实际图像核定。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:422`。绑定：尚无确认绑定

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：现存东库5间、南库10间，黄瓦硬山，内两层；官方8037图可见砖墙与两排小窗。
  - 实现：冻结树无现存两库，旧尺寸文档卷棚顶不能继承。
  - 差异/缺口：正文旧大堂/小堂/办公等已失，不等于现存库消失；完整窗口和两库足迹未注册。
  - 动作：按东/南两个现存 child 规划，先匹配宫墙/河/角楼；不复建旧办公群或卷棚屋顶。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：现存东库5间、南库10间，黄瓦硬山，内两层；官方8037图可见砖墙与两排小窗。
  - 实现：冻结树无现存两库，旧尺寸文档卷棚顶不能继承。
  - 差异/缺口：正文旧大堂/小堂/办公等已失，不等于现存库消失；完整窗口和两库足迹未注册。
  - 动作：按东/南两个现存 child 规划，先匹配宫墙/河/角楼；不复建旧办公群或卷棚屋顶。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：现存东库5间、南库10间，黄瓦硬山，内两层；官方8037图可见砖墙与两排小窗。
  - 实现：冻结树无现存两库，旧尺寸文档卷棚顶不能继承。
  - 差异/缺口：正文旧大堂/小堂/办公等已失，不等于现存库消失；完整窗口和两库足迹未注册。
  - 动作：按东/南两个现存 child 规划，先匹配宫墙/河/角楼；不复建旧办公群或卷棚屋顶。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · SOURCE_PRESENT_REGISTRATION
  - 源据：现存东库5间、南库10间，黄瓦硬山，内两层；官方8037图可见砖墙与两排小窗。
  - 实现：冻结树无现存两库，旧尺寸文档卷棚顶不能继承。
  - 差异/缺口：正文旧大堂/小堂/办公等已失，不等于现存库消失；完整窗口和两库足迹未注册。
  - 动作：按东/南两个现存 child 规划，先匹配宫墙/河/角楼；不复建旧办公群或卷棚屋顶。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：现存东库5间、南库10间，黄瓦硬山，内两层；官方8037图可见砖墙与两排小窗。
  - 实现：冻结树无现存两库，旧尺寸文档卷棚顶不能继承。
  - 差异/缺口：正文旧大堂/小堂/办公等已失，不等于现存库消失；完整窗口和两库足迹未注册。
  - 动作：按东/南两个现存 child 规划，先匹配宫墙/河/角楼；不复建旧办公群或卷棚屋顶。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
### interior：保留 UNREVIEWED

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：正文明确两层库内，但无完整室内照片。
  - 实现：两层库体未实现。
  - 差异/缺口：楼板/梯/分隔尺寸未知，不可从两排窗反推可通行全楼。
  - 动作：结构阶段可保留两层拓扑，入口/梯待证后才开放；不放仪仗库存。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“家具类型/数量/位置/朝向/比例”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作家具类型/数量/位置/朝向/比例已经核验。
  - 差异/缺口：家具类型/数量/位置/朝向/比例的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起家具类型/数量/位置/朝向/比例的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“画/匾联/镜/灯/帘/器物关系”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作画/匾联/镜/灯/帘/器物关系已经核验。
  - 差异/缺口：画/匾联/镜/灯/帘/器物关系的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起画/匾联/镜/灯/帘/器物关系的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：官方叙述包含历史已失房屋；现状几何须凭实际图像核定。
  - 实现：没有已确认此单体的 room/角色注册。
  - 差异/缺口：历史职能房名不一定对应一座现存独立实体。
  - 动作：先分现存建筑和历史职能；用途文字不能支持现代家具摆放。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：銮驾库：已有主体/父页来源，但未提供可确认的本项“可见缺物/无据模型物件”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作可见缺物/无据模型物件已经核验。
  - 差异/缺口：可见缺物/无据模型物件的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起可见缺物/无据模型物件的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-335E0A943698, SRC-6315D2856BF0, SRC-712BB3206158, LUANJIA-PAGE, LUANJIA-PHOTO；代码：data/zones/outer-east.json#/items; src/scene/zones/ZoneBase.js:146-235#hall-dispatch; src/scene/palace/special/RemainingOuterHalls.js:1-510#exact-identity-RECORDS

## FC-1DB501EB23 · 南三所中所后殿撷芳殿

保留全部三进任务、六现有声明与撷芳歧义；未知家具不是空历史房。
原要求：仓库命名待核，勿与中所后殿重复新建；仓库名称包含撷芳殿，但现有官方证据尚未精确证成中所后殿；保留待核记录，不与其他后殿重复新建。
需求锚点：`docs/photo-fidelity/MASTER-PROMPT.md:423`。绑定：data/zones/outer-east.json#/items/15

### exterior：保留 UNREVIEWED

- `footprint_orientation_court_connections` · 平面/朝向/院落连接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `storeys_roof_type_ridge_pitch_eaves_colour` · 层数/屋顶/脊坡/出檐/颜色 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `bays_columns_brackets_beams_paint_zones` · 开间/柱列/斗栱/梁枋/彩画 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `doors_windows_openings_walls_screens` · 门窗/开口/墙/隔扇 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿撷芳殿：已有主体/父页来源，但未提供可确认的本项“门窗/开口/墙/隔扇”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作门窗/开口/墙/隔扇已经核验。
  - 差异/缺口：门窗/开口/墙/隔扇的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起门窗/开口/墙/隔扇的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `terrace_steps_imperial_ramp_rails_posts` · 台基/月台/踏步/御路/栏杆 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿撷芳殿：已有主体/父页来源，但未提供可确认的本项“台基/月台/踏步/御路/栏杆”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作台基/月台/踏步/御路/栏杆已经核验。
  - 差异/缺口：台基/月台/踏步/御路/栏杆的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起台基/月台/踏步/御路/栏杆的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `porches_corridors_ear_rooms_rear_halls_vertical_joins` · 廊/耳房/后殿/高差衔接 · SOURCE_PRESENT_REGISTRATION
  - 源据：三所各三进、中后殿五间、绿瓦硬山；九正殿拓扑有源，配殿/耳房等另在 EXPAND-04。
  - 实现：现有三列两排六个壳，z39/68.9；本条有拟名声明但进次未证。
  - 差异/缺口：无法靠名字/宽度证北排是中殿还是后殿；四未绑定 FC 不是四个必须新建体。
  - 动作：先用现代屋面足迹/可定位相机锁定前三中三后三；保留六壳和所有原 ID，不自动合并撷芳。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `plaques_text_placement_orientation_occlusion` · 牌匾/文字/朝向/遮挡 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿撷芳殿：已有主体/父页来源，但未提供可确认的本项“牌匾/文字/朝向/遮挡”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作牌匾/文字/朝向/遮挡已经核验。
  - 差异/缺口：牌匾/文字/朝向/遮挡的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起牌匾/文字/朝向/遮挡的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `unique_courtyard_facilities_locations` · 独有院落设施/位置 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿撷芳殿：已有主体/父页来源，但未提供可确认的本项“独有院落设施/位置”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作独有院落设施/位置已经核验。
  - 差异/缺口：独有院落设施/位置的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起独有院落设施/位置的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
### interior：保留 PARTIAL

- `room_partitions_portals_column_grid_levels_steps_floor` · 分隔/开口/柱网/楼层/台阶/地面 · SOURCE_PRESENT_REGISTRATION
  - 源据：前中后殿历史房间分隔有文字，但未有与当前六壳一一对应的实景。
  - 实现：六 existing declarations 的 room/bounds/spawn 保留；未绑定 FC 不擅造房间。
  - 差异/缺口：名称与物理进次未确认；工程房间边界不是历史已证。
  - 动作：先完成实体对应，再逐房找总览/侧向/顶部；不要将六壳称六个已确认空历史房间。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `ceilings_caissons_frames_paint_screens_fixed_joinery` · 天花/藻井/梁架/内檐/固定装修 · FEATURE_SOURCE_GAP
  - 源据：南三所中所后殿撷芳殿：已有主体/父页来源，但未提供可确认的本项“天花/藻井/梁架/内檐/固定装修”全覆盖证据。
  - 实现：本特征见该对象的声明及构造锚点；不能把壳或名称当作天花/藻井/梁架/内檐/固定装修已经核验。
  - 差异/缺口：天花/藻井/梁架/内檐/固定装修的逐实例数量、可见范围或现状版本仍需补证；不能从相邻殿堂模板补齐。
  - 动作：仅挂起天花/藻井/梁架/内檐/固定装修的缺证部分；先找本对象有题注图/相应方向，再对现有实现作有界差异单。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `principal_furniture_type_count_location_facing_scale` · 家具类型/数量/位置/朝向/比例 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `pictures_couplets_mirrors_lights_curtains_ornament_relations` · 画/匾联/镜/灯/帘/器物关系 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `function_specificity_worship_library_residential_exhibition` · 宗教/藏书/寝居/展厅用途 · SOURCE_PRESENT_REGISTRATION
  - 源据：南三所为皇子居住沿革；具体期次/用途随时间变化。
  - 实现：保留既有角色/路线，未知库存不会证实现代寝具。
  - 差异/缺口：官图7996明确中所中殿；1925/1988名称讨论没有证撷芳=中所后殿。
  - 动作：按目标现状区分历史用途与当前展陈；不以人物层改回已拆建筑。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `visible_missing_objects_and_unsupported_model_objects` · 可见缺物/无据模型物件 · FEATURE_SOURCE_GAP
  - 源据：未见这些对应房间的现代主要家具清单；历史炕/祭器或宁寿宫灶照片不能移植。
  - 实现：当前六声明已 withheld 每壳8个通用网格及相应碰撞/cover，共48网格；它们不是48件已识别历史文物。
  - 差异/缺口：UNKNOWN_INVENTORY_WITHHELD，不是知道空室；室内未知与身份未知同时保留。
  - 动作：保留本轮去无据家具措施，补本房照片才允许重添；不可把未知转 accepted/known-empty。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15
- `unsupported-generic-furniture-withheld` · unsupported-generic-furniture-withheld · IMPLEMENTED_VERIFY_PENDING
  - 源据：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 实现：799390a 已含本项有限修正；不是本只读审查的新实现。
  - 差异/缺口：Eight generic props and associated collision/cover withheld. Not known empty, room identity/bounds/navigation not historically validated.
  - 动作：保持原有范围、status、acceptedScope 与证据记录；补真实浏览器同视角再验收，不覆盖其他必需项。
  - 源：SRC-285952CB9BBA, SRC-EA5410146513, SRC-B283E01FC208, SRC-735B379D98C4, SRC-357B308002BE, SRC-FCFA7921E97E, SRC-712BB3206158, NANSANSUO-PAGE, NANSANSUO-AERIAL, NANSANSUO-MIDDLE-HALL, NANSANSUO-NAME-P20, HARD-GABLES-2020；代码：src/scene/palace/NansansuoInventoryPolicy.js:1-114#RECORDS-and-validator; src/scene/zones/ZoneBase.js:146-147#explicit-policy-validation; src/scene/zones/ZoneBase.js:234#nansansuoUnknownHall; src/scene/palace/kit.js:475-480#nansansuoUnknownHall; src/scene/palace/special/RemainingOuterHalls.js:1784-1792#sansuo-augmentation; data/zones/outer-east.json#/items/15

## 6 个 AUX 声明（不是南三所六殿）

### AUX-AF5419B9A3CD · 文华院围墙
声明 `data/zones/outer-east.json#/items/1`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/bays_columns_brackets_beams_paint_zones: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/doors_windows_openings_walls_screens: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/terrace_steps_imperial_ramp_rails_posts: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/plaques_text_placement_orientation_occlusion: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/unique_courtyard_facilities_locations: EXISTING_REQUIRES_BROWSER。items/1 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/room_partitions_portals_column_grid_levels_steps_floor: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/principal_furniture_type_count_location_facing_scale: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/function_specificity_worship_library_residential_exhibition: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/visible_missing_objects_and_unsupported_model_objects: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
### AUX-13BC1DFCE1D7 · 文华院语义范围
声明 `data/zones/outer-east.json#/items/6`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/bays_columns_brackets_beams_paint_zones: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/doors_windows_openings_walls_screens: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/terrace_steps_imperial_ramp_rails_posts: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/plaques_text_placement_orientation_occlusion: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/unique_courtyard_facilities_locations: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/room_partitions_portals_column_grid_levels_steps_floor: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/principal_furniture_type_count_location_facing_scale: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/function_specificity_worship_library_residential_exhibition: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/visible_missing_objects_and_unsupported_model_objects: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
### AUX-BC97E8DBD217 · 文渊院围墙
声明 `data/zones/outer-east.json#/items/7`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/bays_columns_brackets_beams_paint_zones: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/doors_windows_openings_walls_screens: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/terrace_steps_imperial_ramp_rails_posts: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/plaques_text_placement_orientation_occlusion: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/unique_courtyard_facilities_locations: EXISTING_REQUIRES_BROWSER。items/7 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/room_partitions_portals_column_grid_levels_steps_floor: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/principal_furniture_type_count_location_facing_scale: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/function_specificity_worship_library_residential_exhibition: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/visible_missing_objects_and_unsupported_model_objects: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
### AUX-EAC56B7C6A2A · 文渊院语义范围
声明 `data/zones/outer-east.json#/items/9`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/bays_columns_brackets_beams_paint_zones: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/doors_windows_openings_walls_screens: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/terrace_steps_imperial_ramp_rails_posts: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/plaques_text_placement_orientation_occlusion: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- exterior/unique_courtyard_facilities_locations: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/room_partitions_portals_column_grid_levels_steps_floor: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/principal_furniture_type_count_location_facing_scale: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/function_specificity_worship_library_residential_exhibition: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
- interior/visible_missing_objects_and_unsupported_model_objects: AGGREGATE_OR_NOT_APPLICABLE。生成0网格/0通用家具；场景用途不等于建成实体。 保留原外观/室内两任务并关联子建筑；全部要求下钻，不给 region 造几何或家具。 锚点：src/scene/zones/ZoneBase.js:345-356#buildRegion; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/6; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9; data/zones/outer-east.json#/items/9
### AUX-709D2756FE0D · 南三所外围墙
声明 `data/zones/outer-east.json#/items/11`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/bays_columns_brackets_beams_paint_zones: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/doors_windows_openings_walls_screens: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/terrace_steps_imperial_ramp_rails_posts: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/plaques_text_placement_orientation_occlusion: AGGREGATE_OR_NOT_APPLICABLE。没有室内/家具。 保留应用范围说明及发现后增补机制。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- exterior/unique_courtyard_facilities_locations: EXISTING_REQUIRES_BROWSER。items/11 已有围墙分段/开口，不是建筑或家具。 对照本院相机/平面逐段标记，保持水系/门洞接口和角色计数。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/room_partitions_portals_column_grid_levels_steps_floor: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/principal_furniture_type_count_location_facing_scale: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/function_specificity_worship_library_residential_exhibition: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
- interior/visible_missing_objects_and_unsupported_model_objects: AGGREGATE_OR_NOT_APPLICABLE。生成围墙段及开口，无房间/通用家具。 建议注明本角色无室内；外观继续逐段检验，不删除原任务。 锚点：src/scene/zones/ZoneBase.js:290-309#buildCourtWalls; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/1; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/7; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11; data/zones/outer-east.json#/items/11
### AUX-1DA0AE7EB391 · 文华穿廊同体引用
声明 `data/zones/outer-east.json#/items/23`；原两 facet 状态保留，canonical 没有 feature 数组，本报告的14条是角色适用性审查，不新增 canonical 任务。通用家具0。

- exterior/footprint_orientation_court_connections: EXISTING_REQUIRES_BROWSER。文华殿穿廊已有 connector 专用声明与 exact-profile，非缺壳。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留现有 items/23 与 architecture id outer-east/wenhua-connector 绑定和 AUX 原任务，只补实际同视角对照。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/storeys_roof_type_ridge_pitch_eaves_colour: EXISTING_REQUIRES_BROWSER。SouthCourtHalls 使用保留歇山 hall 或旋转 gable 穿廊屋顶。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的层数/屋顶/脊坡/出檐/颜色；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/bays_columns_brackets_beams_paint_zones: EXISTING_REQUIRES_BROWSER。沿用五开间 hall 与单跨穿廊拟合；非实测彩画/斗栱。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的开间/柱列/斗栱/梁枋/彩画；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/doors_windows_openings_walls_screens: EXISTING_REQUIRES_BROWSER。正殿/后殿前后 portal 已有；穿廊两端开通、侧墙连续。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的门窗/开口/墙/隔扇；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/terrace_steps_imperial_ramp_rails_posts: EXISTING_REQUIRES_BROWSER。三个对象楼面均 1.2；相接内阶藏于连接台基下，安全连续。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的台基/月台/踏步/御路/栏杆；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/porches_corridors_ear_rooms_rear_halls_vertical_joins: EXISTING_REQUIRES_BROWSER。文华前殿后缘 -190.5 与穿廊南端、后殿前缘 -173 与穿廊北端相接。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的廊/耳房/后殿/高差衔接；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/plaques_text_placement_orientation_occlusion: EXISTING_REQUIRES_BROWSER。主敬殿牌在穿廊梁下悬挂已有源；前殿名牌仍简化。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的牌匾/文字/朝向/遮挡；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- exterior/unique_courtyard_facilities_locations: EXISTING_REQUIRES_BROWSER。SouthCourtTrees 另有四个观测树干拟合；其他院设未因此通过。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留已有实现，从真实浏览器匹配本对象的独有院落设施/位置；只关闭已观察的差异，未见方向保留未知。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/room_partitions_portals_column_grid_levels_steps_floor: EXISTING_REQUIRES_BROWSER。专用楼面/连续入口及真实展示设备已有。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 核入口和设备间穿行；保持单个圆形通道，不把反射当第二洞。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/ceilings_caissons_frames_paint_screens_fixed_joinery: EXISTING_REQUIRES_BROWSER。前殿圆洞屏风/横竖框、穿廊天花、后殿 R48 格井/圆形轮廓已有。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 逐对象核天花、隔断与固定屏风，不把现有格井当待新建。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/principal_furniture_type_count_location_facing_scale: EXISTING_REQUIRES_BROWSER。前殿岛墙和一座北侧低柜、穿廊两侧柜/斜托板/挡边、后殿圆展台均已实现。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 按本区全景核设备类别、数量、朝向及通道；不声称第二期作品已核。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/pictures_couplets_mirrors_lights_curtains_ornament_relations: EXISTING_REQUIRES_BROWSER。已有灯带、后殿吊轨及一个空白吊签示例；无虚构书画复制品。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 核可见器材关系，未确认画作保持空白，不把灯轨当古梁。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/function_specificity_worship_library_residential_exhibition: EXISTING_REQUIRES_BROWSER。wenhua-gallery 不是古代寝殿/佛堂。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 保留目标版本声明；若变更到当期，先补本期完整来源。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
- interior/visible_missing_objects_and_unsupported_model_objects: EXISTING_REQUIRES_BROWSER。没有 generic royal furniture；专用展陈是已有成果。 与 FC-0B08F51957 共用该实体的同一证据/差异；保留本 AUX 原声明，不增加第二栋或第二套展陈。 使用实机对照清单记录物体级差异，保留 source-bound 既有设备。 锚点：src/scene/zones/ZoneBase.js:146-156#buildHall; src/scene/zones/ZoneBase.js:159-235#buildHallBaseline; src/scene/palace/special/SouthCourtProfiles.js:7-15#SOUTH_COURTS.wenhua; src/scene/palace/special/SouthCourtHalls.js:7-68#buildSouthCourtHall; src/scene/palace/special/SouthGalleryDisplays.js:18-107#buildSouthGalleryDisplays; src/scene/palace/special/SouthCourtTrees.js:4-17#wenhua-approach; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23; data/zones/outer-east.json#/items/23
