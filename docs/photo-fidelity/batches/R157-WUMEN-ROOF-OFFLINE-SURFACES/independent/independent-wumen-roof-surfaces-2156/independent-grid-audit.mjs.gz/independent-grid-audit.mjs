import fs from'node:fs';import assert from'node:assert/strict';import * as T from'../r157-wumen-joint-layout-1622/node_modules/three/build/three.module.js';
import{createUpperReassemblyContract}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/upper-contract.mjs';
import{createRoofSection}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/roof-section-evaluator.mjs';
import{buildRoofSectionSurfaces}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/roof-section-surfaces.mjs';
const C=createUpperReassemblyContract(),rows=[];const key=tri=>JSON.stringify(tri.map(p=>p.map(x=>Object.is(x,-0)?0:x)).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))));
for(const i of C.roofKnots.instances)for(const layer of i.kind==='pavilion'?['lower','upper']:['single'])for(const mode of['predecessor','proposal']){
 const q=createRoofSection(i.id,layer,mode),r=q.recipe,mat={tile:new T.MeshStandardMaterial(),soffit:new T.MeshStandardMaterial(),fascia:new T.MeshStandardMaterial()},b=buildRoofSectionSurfaces(q,mat);let total=0,removed=0,quantError=0;const expectedLedger=[];
 try{for(let face=0;face<4;face++)for(const kind of['tile','soffit','fascia']){
  const rs=Math.max(2,Math.round(r.sampleCounts.nT*(1-r.tw)*1.5));
  const ts=kind==='tile'?[...new Set([...Array.from({length:r.sampleCounts.nT+1},(_,j)=>j/r.sampleCounts.nT),r.tw])].sort((a,b)=>a-b):kind==='soffit'?Array.from({length:rs+1},(_,j)=>j===rs?1:r.tw+(1-r.tw)*(j/rs)):[0,1];
  const ss=Array.from({length:r.sampleCounts.nU+1},(_,j)=>(1-Math.cos(Math.PI*j/r.sampleCounts.nU))/2),grid=ts.map(row=>ss.map(s=>{const p=q.point(face,kind==='fascia'?1:row,s);p[1]+=kind==='tile'?0:kind==='soffit'?-r.thickness:row===0?.03:-1.5*r.thickness;return p;}));
  const expected=[],ledger=[];for(let a=0;a<ts.length-1;a++)for(let c=0;c<ss.length-1;c++)for(const [half,cells]of [[[a,c],[a,c+1],[a+1,c]],[[a,c+1],[a+1,c+1],[a+1,c]]].entries()){
   const raw=cells.map(([x,y])=>grid[x][y]),v=raw.map(p=>p.map(Math.fround)),cross=new T.Vector3().crossVectors(new T.Vector3(...v[1]).sub(new T.Vector3(...v[0])),new T.Vector3(...v[2]).sub(new T.Vector3(...v[0])));
   if(cross.lengthSq()===0){assert.equal(kind,'tile');assert.notEqual(layer,'lower');assert.equal(a,0);assert.ok(raw.some((p,j)=>raw.slice(j+1).some(v=>p.every((x,k)=>x===v[k]))));removed++;expectedLedger.push({kind,face,row:a,col:c,half,reason:'ANALYTIC_T0_APEX_OR_RIDGE_DUPLICATE'});continue;}
   expected.push(key(v));for(const p of raw)for(const x of p)quantError=Math.max(quantError,Math.abs(Math.fround(x)-x));
  }
  const m=b.group.children.find(m=>m.name===kind+'/'+face),g=m.geometry,p=g.attributes.position,idx=g.index.array,actual=[];
  assert.deepEqual(g.drawRange,{start:0,count:Infinity});assert.deepEqual(g.groups,[]);
  for(let a=0;a<idx.length;a+=3)actual.push(key([0,1,2].map(j=>Array.from(p.array.slice(idx[a+j]*3,idx[a+j]*3+3)))));
  assert.deepEqual(actual.sort(),expected.sort());total+=actual.length;
 }
 assert.deepEqual(b.audit.removedStructuralTriangles,expectedLedger);
 rows.push({id:i.id,layer,mode,triangles:total,removed,maxAttributeFloat32Quantization:quantError,exactCompleteGridMultiset:true,defaultCompleteDrawRange:true,noGroups:true});
 }finally{b.dispose();for(const m of Object.values(mat))m.dispose();}
}
const totals=Object.fromEntries(['predecessor','proposal'].map(mode=>[mode,rows.filter(r=>r.mode===mode).reduce((a,r)=>({layers:a.layers+1,triangles:a.triangles+r.triangles,removed:a.removed+r.removed}),{layers:0,triangles:0,removed:0})]));
fs.writeFileSync(new URL('./independent-grid-audit.json',import.meta.url),JSON.stringify({scope:'ACTUAL_FIXED_OFFLINE_GEOMETRY_NOT_WORLD',rows,totals},null,2)+'\n');console.log(JSON.stringify(totals));
