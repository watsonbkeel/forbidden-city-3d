import fs from'node:fs';import assert from'node:assert/strict';
import{createRoofSection}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/roof-section-evaluator.mjs';
import{createUpperReassemblyContract}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/upper-contract.mjs';
const c=createUpperReassemblyContract(),rows=[];let maxProfile=0;
for(const i of c.roofKnots.instances)for(const layer of i.kind==='pavilion'?['lower','upper']:['single'])for(const mode of ['predecessor','proposal']){
 const q=createRoofSection(i.id,layer,mode),r=c.roofRecipe[layer==='lower'?'pavilionLower':layer==='upper'?'pavilionUpper':'wingSingle'],k=i[layer],m=mode==='proposal'?'proposal':'old';
 const eave=layer==='lower'?(m==='proposal'?k.newSkirtKnotsInnerBearingEave.map(a=>a[2]):[k.oldSkirtKnotsInnerBearingEave[2],k.oldSkirtKnotsInnerBearingEave[2]]):k[m].eaveHalf;
 assert.deepEqual(q.ring(1)[2],eave);
 if(layer==='lower')assert.deepEqual(q.ring(0)[2],m==='proposal'?k.newSkirtKnotsInnerBearingEave.map(a=>a[0]):[k.oldSkirtKnotsInnerBearingEave[0],k.oldSkirtKnotsInnerBearingEave[0]]);
 for(const t of [.1234567,.37,.63,.913457]){const expected=r.eaveY+r.H*(r.profileCoefficient*(1-t)+(1-r.profileCoefficient)*(1-t)**2),error=Math.abs(q.baseY(t)-expected);assert.equal(error,0);maxProfile=Math.max(maxProfile,error);}
 rows.push({id:i.id,layer,mode,allEndpointAndIndependentMidProfileChecksPassed:true});
}
const q=createRoofSection(c.roofKnots.instances[0].id,'lower','proposal');let tiny;try{tiny={returned:q.uv(0,.9,.2,Number.MIN_VALUE).map(x=>String(x)),rejected:false};}catch(e){tiny={rejected:true,message:e.message};}
const result={testedPairs:rows.length,maxIndependentProfileError:maxProfile,rows,routeFlag:{present:Object.hasOwn(q,'routeAccepted'),value:String(q.routeAccepted)},tinyPositiveTileSize:tiny};fs.writeFileSync(new URL('./arithmetic-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({testedPairs:rows.length,maxProfile,routeFlag:result.routeFlag,tiny}));
