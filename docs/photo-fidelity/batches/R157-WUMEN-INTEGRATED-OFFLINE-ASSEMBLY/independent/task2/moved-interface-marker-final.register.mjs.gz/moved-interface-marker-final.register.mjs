import{register}from'node:module';register("file:///workspace/scratch/02a8023d1a85/independent-wumen-upper-assembly-2348/moved-interface-marker-final.loader.mjs",import.meta.url);
