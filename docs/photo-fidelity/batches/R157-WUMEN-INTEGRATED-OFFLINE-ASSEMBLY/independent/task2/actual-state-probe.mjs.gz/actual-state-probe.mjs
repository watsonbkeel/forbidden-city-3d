import fs from 'node:fs';
import {captureGate} from '../r157-wumen-joint-layout-1622/tests/lib/gate-tower-fixture.mjs';
import {PalaceBuilder} from '../r157-wumen-joint-layout-1622/src/scene/PalaceBuilder.js';
import {buildWumenAssemblyCandidate} from '../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/upper-assembly.mjs';
const collect=g=>{const s=new Set();g.traverse(o=>{if(o.geometry)s.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:o.material?[o.material]:[]){s.add(m);for(const v of Object.values(m))if(v?.isTexture)s.add(v);}});return s;};
const retire=g=>{const s=collect(g),seen=new Set();for(const r of s)r.addEventListener('dispose',()=>seen.add(r));for(const r of [...s].sort((a,b)=>!!b.isMaterial-!!a.isMaterial))if(!seen.has(r))r.dispose();};
const a=captureGate(),b=buildWumenAssemblyCandidate({reference:a}),out={linkBeamFlags:[],markerPos:[]};
for(let k=0;k<2;k++){const old=a.group.children[[16,17][k]],now=b.links[k].group;out.linkBeamFlags.push({side:k,old:old.children.filter(o=>o.name.includes('beam')).map(o=>({name:o.name,castShadow:o.castShadow,receiveShadow:o.receiveShadow})),current:now.children.filter(o=>o.name.includes('beam')).map(o=>({name:o.name,castShadow:o.castShadow,receiveShadow:o.receiveShadow}))});}
b.dispose();retire(a.group);
const ar=captureGate(),original=PalaceBuilder.prototype.buildGate;let captured;const events=new Map();
PalaceBuilder.prototype.buildGate=function(...args){const finish=this.finish;this.finish=function(g){captured=g;for(const r of collect(g)){events.set(r,0);r.addEventListener('dispose',()=>events.set(r,events.get(r)+1));}return finish.call(this,g);};return original.apply(this,args);};
try{buildWumenAssemblyCandidate({reference:ar,onResource:()=>{throw Error('INDEPENDENT_OBSERVER_FAILURE');}});out.failure='did not throw';}catch(e){out.failure=e.message;}finally{PalaceBuilder.prototype.buildGate=original;}
out.failureResourceCounts={captured:events.size,zero:[...events.values()].filter(n=>n===0).length,once:[...events.values()].filter(n=>n===1).length,multiple:[...events.values()].filter(n=>n>1).length};
if(captured){const seen=new Set([...events].filter(([,n])=>n).map(([r])=>r));for(const r of events.keys())r.addEventListener('dispose',()=>seen.add(r));for(const r of [...events.keys()].sort((a,b)=>!!b.isMaterial-!!a.isMaterial))if(!seen.has(r))r.dispose();}retire(ar.group);
fs.writeFileSync(new URL('./actual-state-probe.json',import.meta.url),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
