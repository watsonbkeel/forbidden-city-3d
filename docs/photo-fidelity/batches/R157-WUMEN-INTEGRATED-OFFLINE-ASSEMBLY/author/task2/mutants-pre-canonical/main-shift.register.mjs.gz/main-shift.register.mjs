import {register} from 'node:module';register("file:///workspace/scratch/02a8023d1a85/wumen-joint-recovery-1607/upper-reassembly-2034/assembly-task2-2323/main-shift.loader.mjs",import.meta.url);
