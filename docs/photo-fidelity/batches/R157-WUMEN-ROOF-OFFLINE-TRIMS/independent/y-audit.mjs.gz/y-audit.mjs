import fs from'node:fs';import assert from'node:assert/strict';import * as T from'../r157-wumen-joint-layout-1622/node_modules/three/build/three.module.js';
import{createUpperReassemblyContract}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/upper-contract.mjs';
import{createRoofSection}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/roof-section-evaluator.mjs';
import{buildRoofSectionTrims}from'../r157-wumen-joint-layout-1622/scripts/photo-fidelity/batches/wumen-joint-layout/roof-section-trims.mjs';
const C=createUpperReassemblyContract(),mat={ridge:new T.MeshStandardMaterial(),gold:new T.MeshStandardMaterial()},rows=[];let maxRecord=null;
function controls(q,f){const r=q.recipe,n=q.layer==='lower'?6:8,t0=q.layer==='upper'?.02:0,pts=[];for(let j=0;j<=n;j++){const t=t0+(1-t0)*j/n,p=q.point(f,t,0);p[1]=q.baseY(t)+r.hr*.6+(t>r.tw?r.lift.L*((t-r.tw)/(1-r.tw))**1.6:0);pts.push(new T.Vector3(...p));}const d=pts.at(-1).clone().sub(pts.at(-3));d.y=0;d.normalize().multiplyScalar(r.hr*3);pts.push(pts.at(-1).clone().add(d).add(new T.Vector3(0,r.hr*1.6,0)));return pts;}
for(const i of C.roofKnots.instances)for(const layer of i.kind==='pavilion'?['lower','upper']:['single']){
 const qs=['predecessor','proposal'].map(mode=>createRoofSection(i.id,layer,mode)),bs=qs.map(q=>buildRoofSectionTrims(q,mat)),row={id:i.id,layer,meshes:bs[0].group.children.length,triangles:bs[0].group.children.reduce((a,m)=>a+m.geometry.index.count/3,0),removedPoles:bs[0].audit.removedPoleTriangles.length,hips:[],meshTopDeltas:[]};
 try{for(let f=0;f<4;f++){
  const meshes=bs.map(b=>b.group.children.find(m=>m.name==='hip/'+f)),ps=meshes.map(m=>m.geometry.attributes.position),ctrl=qs.map(q=>controls(q,f)),curves=ctrl.map(a=>new T.CatmullRomCurve3(a));assert.deepEqual(ctrl[0].map(p=>p.y),ctrl[1].map(p=>p.y));const frames=curves.map(c=>c.computeFrenetFrames(8,false));let largest=null;
  for(let j=0;j<ps[0].count;j++){
   const ring=Math.floor(j/5),radial=j%5,u=ring/8,theta=radial/4*Math.PI*2,r=qs[0].recipe.hr;
   const centers=curves.map(c=>c.getPointAt(u));
   const offsets=frames.map(F=>r*(-Math.cos(theta)*F.normals[ring].y+Math.sin(theta)*F.binormals[ring].y));
   const quant=ps.map((p,k)=>p.getY(j)-(centers[k].y+offsets[k]));
   const actual=ps[1].getY(j)-ps[0].getY(j),center=centers[1].y-centers[0].y,section=offsets[1]-offsets[0],roundoff=quant[1]-quant[0];assert.ok(Math.abs(actual-center-section-roundoff)<1e-12);
   const v={id:i.id,layer,face:f,index:j,ring,radial,arcFraction:u,oldCurveParameter:curves[0].getUtoTmapping(u),newCurveParameter:curves[1].getUtoTmapping(u),actualYDelta:actual,centerArcReparameterizationYDelta:center,fixedRadiusFrameOffsetYDelta:section,float32Difference:roundoff,controlsYEqual:true};
   if(!largest||Math.abs(actual)>Math.abs(largest.actualYDelta))largest=v;if(!maxRecord||Math.abs(actual)>Math.abs(maxRecord.actualYDelta))maxRecord=v;
  }row.hips.push(largest);
 }
 for(let j=0;j<bs[0].group.children.length;j++){const m0=bs[0].group.children[j],m1=bs[1].group.children[j];assert.equal(m0.name,m1.name);const old=new T.Box3().setFromObject(m0),now=new T.Box3().setFromObject(m1);row.meshTopDeltas.push({mesh:m0.name,oldMaxY:old.max.y,newMaxY:now.max.y,delta:now.max.y-old.max.y});}
 rows.push(row);
 }finally{bs.forEach(b=>b.dispose());}
}
Object.values(mat).forEach(m=>m.dispose());const sums=rows.reduce((a,r)=>({layers:a.layers+1,meshes:a.meshes+r.meshes,triangles:a.triangles+r.triangles,removedPoles:a.removedPoles+r.removedPoles}),{layers:0,meshes:0,triangles:0,removedPoles:0});
fs.writeFileSync(new URL('./y-audit.json',import.meta.url),JSON.stringify({scope:'OFFLINE_MATCHED_NATIVE_TUBE_VERTEX_INDICES_NOT_PHYSICAL_CORRESPONDENCE',sums,maxRecord,rows},null,2)+'\n');console.log(JSON.stringify({sums,maxRecord,maxMeshTopDelta:Math.max(...rows.flatMap(r=>r.meshTopDeltas.map(x=>x.delta)))}));
