import {WUMEN_JOINT_ASCENT_FIT} from './WumenJointAscentFit.js';
import {validateWumenJointAscentBinding} from './WumenJointAscentContact.js';
import {pathFootprintCovered} from './WumenJointAscentCoverage.js';
import {wumenJointBodySweep} from './WumenJointAscentSweep.js';

// Isolated single-plane grounded substep only. No shared controller hook,
// landing, release-to-air or cross-plane seam transition is implemented here.
const refused=status=>({status,accepted:false,releaseImplemented:false});
const contains=(p,x,z)=>x>=p.minX&&x<=p.maxX&&z>=p.minZ&&z<=p.maxZ;
const height=(p,x,z)=>p.y0+(p.y1-p.y0)*((p.axis==='x'?x:z)-p.a0)/(p.a1-p.a0);
export function tryWumenJointGroundStep(cm,from,to,state,radius=.5){
 if(![from,to].every(p=>p?.isVector3&&p.toArray().every(Number.isFinite))||!Number.isFinite(radius)||radius<=0||!state||typeof state.airborne!=='boolean')throw TypeError('Wumen joint step requires finite feet and explicit movement state');
 // Fixed expected domain does not shrink when a real owner has been removed.
 const minX=Math.min(from.x,to.x)-radius,maxX=Math.max(from.x,to.x)+radius,minZ=Math.min(from.z,to.z)-radius,maxZ=Math.max(from.z,to.z)+radius;
 const domain=WUMEN_JOINT_ASCENT_FIT.pieces.filter(p=>p.minX<=maxX&&p.maxX>=minX&&p.minZ<=maxZ&&p.maxZ>=minZ);
 if(!domain.length)return{status:'OUTSIDE'};
 const binding=validateWumenJointAscentBinding(cm);
 if(!binding)return{status:'OUTSIDE'};
 if(state.kind!=='player')return refused('UNSUPPORTED_ACTOR');
 if(state.airborne)return refused('AIRBORNE_UNHANDLED');
 if(Math.hypot(to.x-from.x,to.z-from.z)>radius*.5)return refused('SUBSTEP_TOO_LONG');
 const live=domain.filter(p=>binding.ownerIDs.includes(p.id)),starts=live.filter(p=>contains(p,from.x,from.z)),ends=live.filter(p=>contains(p,to.x,to.z));
 if(!starts.length||!ends.length)return refused('UNSUPPORTED');
 // Tiny numeric round-trip allowance only; never choose a lower implicit floor.
 const matching=starts.filter(p=>Math.abs(height(p,from.x,from.z)-from.y)<=1e-9);
 if(!matching.length)return refused('INVALID_START');
 const same=matching.filter(p=>ends.includes(p));
 if(!same.length)return refused('SEAM_UNRESOLVED');
 const p=same.find(p=>pathFootprintCovered([p],[from.x,from.z],[to.x,to.z],radius));
 if(!p)return refused('PARTIAL_SUPPORT');
 const position=to.clone();position.y=height(p,to.x,to.z);
 if(wumenJointBodySweep(cm,from,position,radius).blocked)return refused('BODY_BLOCKED');
 return{status:'SUPPORTED',accepted:true,feetY:position.y,position,ownerID:p.id,routeAcceptance:false};
}
